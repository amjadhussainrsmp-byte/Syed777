import { i as __toESM } from "./_runtime.mjs";
import { n as require_react } from "./_libs/@radix-ui/react-compose-refs+[...].mjs";
import { J as require_jsx_runtime, b as Link } from "./_libs/@tanstack/react-router+[...].mjs";
import { t as Button } from "./_ssr/button-CJlkzDbB.mjs";
import { c as ArrowLeft, r as Share2, s as ArrowRight } from "./_libs/lucide-react.mjs";
import { o as Route$8 } from "./_ssr/router-BRWYFOf0.mjs";
import { t as getPoet } from "./_ssr/poets-Dez-ct4W.mjs";
import { t as FavoriteButton } from "./_ssr/favorite-button-467Gt0dM.mjs";
import { n as VerseBlock } from "./_ssr/verse-block-Bu6x1CUL.mjs";
import { t as ScriptToggle } from "./_ssr/script-toggle-JvrcbABm.mjs";
import { n as verses, t as getVerse } from "./_ssr/verses-CeHcBRqB.mjs";
import { n as PoetMark } from "./_ssr/poet-card-B1I16-Eh.mjs";
import { t as Badge } from "./_ssr/badge-Cr0l7nxv.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_id-D_Tn6tO5.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function VersePage() {
	const { id } = Route$8.useParams();
	const verse = getVerse(id);
	const [copied, setCopied] = (0, import_react.useState)(false);
	if (!verse) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto max-w-2xl px-4 py-24 text-center",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "font-display text-3xl",
			children: "This verse is not on the shelf"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			asChild: true,
			variant: "outline",
			className: "mt-6",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/poetry",
				children: "Back to poetry"
			})
		})]
	});
	const poet = getPoet(verse.poetSlug);
	const index = verses.findIndex((v) => v.id === verse.id);
	const prev = index > 0 ? verses[index - 1] : void 0;
	const next = index >= 0 && index < verses.length - 1 ? verses[index + 1] : void 0;
	const shareText = `${verse.title} — ${poet?.name ?? ""}\n${verse.english}`;
	async function share() {
		const url = window.location.href;
		try {
			await navigator.clipboard.writeText(`${shareText}\n${url}`);
			setCopied(true);
			window.setTimeout(() => setCopied(false), 1600);
		} catch {
			setCopied(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto max-w-3xl px-4 py-12 md:px-6 md:py-16",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/poetry",
				className: "inline-flex h-11 items-center gap-2 text-sm text-muted hover:text-fg",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "size-4" }), " All poetry"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-8 flex flex-wrap items-center justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
						variant: "outline",
						className: "rounded-full",
						children: verse.form
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-sm text-subtle",
						children: verse.collection === "sant-vani" ? "Sant vani" : "Sufi kalam"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FavoriteButton, {
						kind: "verse",
						id: verse.id
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "outline",
						size: "sm",
						onClick: () => void share(),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Share2, { className: "size-4" }), copied ? "Copied" : "Share"]
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-6 font-display text-4xl tracking-tight",
				children: verse.title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-6",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScriptToggle, {})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("article", {
				className: "mt-8 rounded-xl bg-surface p-6 shadow-[var(--shadow-border)] md:p-10",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VerseBlock, { verse })
			}),
			verse.note ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-6 text-sm leading-relaxed text-muted",
				children: verse.note
			}) : null,
			poet ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/poets/$slug",
				params: { slug: poet.slug },
				className: "mt-10 flex items-center gap-4 rounded-xl bg-bg-deep p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PoetMark, { poet }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-xl",
					children: poet.name
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-muted",
					children: [
						poet.years,
						" · ",
						poet.place
					]
				})] })]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-12 flex items-center justify-between gap-4 border-t border-border pt-6",
				children: [prev ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/poetry/$id",
					params: { id: prev.id },
					className: "text-sm text-muted hover:text-fg",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "flex items-center gap-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "size-4" }), " Previous"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "mt-1 block font-display text-lg text-fg",
						children: prev.title
					})]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {}), next ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/poetry/$id",
					params: { id: next.id },
					className: "text-right text-sm text-muted hover:text-fg",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "flex items-center justify-end gap-1",
						children: ["Next ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-4" })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "mt-1 block font-display text-lg text-fg",
						children: next.title
					})]
				}) : null]
			})
		]
	});
}
//#endregion
export { VersePage as component };
