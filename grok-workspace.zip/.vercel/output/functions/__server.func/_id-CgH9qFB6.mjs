import { J as require_jsx_runtime, b as Link } from "./_libs/@tanstack/react-router+[...].mjs";
import { t as Button } from "./_ssr/button-CJlkzDbB.mjs";
import { c as ArrowLeft } from "./_libs/lucide-react.mjs";
import { i as Route$4 } from "./_ssr/router-BRWYFOf0.mjs";
import { t as getPoet } from "./_ssr/poets-Dez-ct4W.mjs";
import { o as getQawwali } from "./_ssr/content-CcAZIJXZ.mjs";
import { t as FavoriteButton } from "./_ssr/favorite-button-467Gt0dM.mjs";
import { r as VerseLines } from "./_ssr/verse-block-Bu6x1CUL.mjs";
import { t as ScriptToggle } from "./_ssr/script-toggle-JvrcbABm.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_id-CgH9qFB6.js
var import_jsx_runtime = require_jsx_runtime();
function QawwaliPage() {
	const { id } = Route$4.useParams();
	const item = getQawwali(id);
	if (!item) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto max-w-2xl px-4 py-24 text-center",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "font-display text-3xl",
			children: "This kalam is not on the shelf"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			asChild: true,
			variant: "outline",
			className: "mt-6",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/qawwali",
				children: "All qawwali"
			})
		})]
	});
	const poet = item.poetSlug ? getPoet(item.poetSlug) : void 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto max-w-3xl px-4 py-12 md:py-16",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/qawwali",
				className: "inline-flex h-11 items-center gap-2 text-sm text-muted hover:text-fg",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "size-4" }), " All qawwali"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-8 flex items-start justify-between gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs uppercase tracking-[0.22em] text-subtle",
						children: item.language
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-2 font-display text-4xl tracking-tight",
						children: item.title
					}),
					poet ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/poets/$slug",
						params: { slug: poet.slug },
						className: "mt-2 inline-block text-sm text-muted hover:underline",
						children: poet.name
					}) : null
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FavoriteButton, {
					kind: "qawwali",
					id: item.id
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-6",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScriptToggle, {})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("article", {
				className: "mt-8 rounded-xl bg-surface p-6 shadow-[var(--shadow-border)] md:p-10",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VerseLines, {
					original: item.original,
					originalScript: item.originalScript,
					hindi: item.hindi,
					roman: item.roman,
					english: item.english
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-6 text-sm leading-relaxed text-muted",
				children: item.note
			})
		]
	});
}
//#endregion
export { QawwaliPage as component };
