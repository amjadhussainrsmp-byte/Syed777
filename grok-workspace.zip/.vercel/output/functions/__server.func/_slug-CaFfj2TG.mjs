import { J as require_jsx_runtime, b as Link } from "./_libs/@tanstack/react-router+[...].mjs";
import { t as Button } from "./_ssr/button-CJlkzDbB.mjs";
import { c as ArrowLeft } from "./_libs/lucide-react.mjs";
import { a as Route$6 } from "./_ssr/router-BRWYFOf0.mjs";
import { t as getPoet } from "./_ssr/poets-Dez-ct4W.mjs";
import { n as VerseBlock } from "./_ssr/verse-block-Bu6x1CUL.mjs";
import { t as ScriptToggle } from "./_ssr/script-toggle-JvrcbABm.mjs";
import { r as versesByPoet } from "./_ssr/verses-CeHcBRqB.mjs";
import { n as PoetMark } from "./_ssr/poet-card-B1I16-Eh.mjs";
import { t as Badge } from "./_ssr/badge-Cr0l7nxv.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_slug-CaFfj2TG.js
var import_jsx_runtime = require_jsx_runtime();
function PoetPage() {
	const { slug } = Route$6.useParams();
	const poet = getPoet(slug);
	const list = versesByPoet(slug);
	if (!poet) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto max-w-2xl px-4 py-24 text-center",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "font-display text-3xl",
			children: "This poet is not on the shelf"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			asChild: true,
			variant: "outline",
			className: "mt-6",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/poets",
				children: "All poets"
			})
		})]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative isolate overflow-hidden",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
			src: "/images/jali.jpg",
			alt: "",
			className: "h-56 w-full object-cover md:h-72"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-gradient-to-t from-bg via-bg/40 to-fg/20" })]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto -mt-14 max-w-3xl px-4 pb-16 md:px-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/poets",
				className: "mb-6 inline-flex h-11 items-center gap-2 text-sm text-muted hover:text-fg",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "size-4" }), " All poets"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start gap-4 rounded-xl bg-surface p-6 shadow-[var(--shadow-border)]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PoetMark, {
					poet,
					className: "size-20"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "font-display text-3xl md:text-4xl",
						children: poet.name
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 font-nastaliq text-xl text-muted",
						dir: "rtl",
						children: poet.nameOriginal
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-3 text-sm text-muted",
						children: [
							poet.years,
							" · ",
							poet.place
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 flex flex-wrap gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
							variant: "soft",
							children: poet.tradition
						}), poet.languages.map((l) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, { children: l }, l))]
					})
				] })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-8 text-lg leading-relaxed text-ink-soft",
				children: poet.bio
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-12 flex items-center justify-between gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-2xl",
					children: "Verses"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScriptToggle, {})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-6 flex flex-col gap-4",
				children: list.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-muted",
					children: "No verses on the shelf yet."
				}) : list.map((v) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/poetry/$id",
					params: { id: v.id },
					className: "rounded-xl bg-surface p-6 shadow-[var(--shadow-border)] transition-shadow duration-fast hover:shadow-[var(--shadow-border-hover)]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mb-4 text-sm text-subtle",
						children: v.title
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VerseBlock, {
						verse: v,
						size: "md"
					})]
				}, v.id))
			})
		]
	})] });
}
//#endregion
export { PoetPage as component };
