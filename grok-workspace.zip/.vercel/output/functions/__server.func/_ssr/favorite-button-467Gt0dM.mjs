import { J as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as cn, t as Button } from "./button-CJlkzDbB.mjs";
import { o as Bookmark } from "../_libs/lucide-react.mjs";
import { m as useFavorites, p as useHydrated } from "./router-BRWYFOf0.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/favorite-button-467Gt0dM.js
var import_jsx_runtime = require_jsx_runtime();
function FavoriteButton({ kind, id, className }) {
	const hydrated = useHydrated();
	const hasStored = useFavorites((s) => s.items[kind].includes(id));
	const toggle = useFavorites((s) => s.toggle);
	const has = hydrated && hasStored;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
		type: "button",
		variant: has ? "default" : "outline",
		size: "sm",
		className: cn("gap-1.5", className),
		onClick: () => toggle(kind, id),
		"aria-pressed": has,
		"aria-label": has ? "Remove from shelf" : "Save to shelf",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bookmark, { className: cn("size-4", has && "fill-current") }), has ? "Saved" : "Save"]
	});
}
//#endregion
export { FavoriteButton as t };
