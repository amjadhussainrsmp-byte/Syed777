import { J as require_jsx_runtime, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as Button } from "./button-CJlkzDbB.mjs";
import { f as PageHead, m as useFavorites, p as useHydrated } from "./router-BRWYFOf0.mjs";
import { t as getPoet } from "./poets-Dez-ct4W.mjs";
import { c as getStory, i as getEbook, l as getTerm, o as getQawwali, s as getQuote } from "./content-CcAZIJXZ.mjs";
import { t as getVerse } from "./verses-CeHcBRqB.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/favorites-M_YtzSFm.js
var import_jsx_runtime = require_jsx_runtime();
function FavoritesPage() {
	const hydrated = useHydrated();
	const items = useFavorites((s) => s.items);
	const total = Object.values(items).reduce((n, arr) => n + arr.length, 0);
	if (!hydrated) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHead, {
		kicker: "Your shelf",
		title: "Saved",
		dek: "Kept in this browser only — a private margin, not an account."
	}) });
	const verses = items.verse.map(getVerse).filter(Boolean);
	const quotes = items.quote.map(getQuote).filter(Boolean);
	const stories = items.story.map(getStory).filter(Boolean);
	const terms = items.term.map(getTerm).filter(Boolean);
	const qawwalis = items.qawwali.map(getQawwali).filter(Boolean);
	const books = items.ebook.map(getEbook).filter(Boolean);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHead, {
		kicker: "Your shelf",
		title: "Saved",
		dek: "Kept in this browser only — a private margin, not an account."
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "mx-auto max-w-3xl px-4 pb-16 md:px-6",
		children: total === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "rounded-xl bg-surface px-6 py-12 text-center shadow-[var(--shadow-border)]",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-2xl",
					children: "The shelf is empty"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-muted",
					children: "Save a verse, a quote, a story — it stays on this device."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					asChild: true,
					className: "mt-6",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/poetry",
						children: "Browse poetry"
					})
				})
			]
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-10",
			children: [
				verses.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-2xl",
					children: "Verses"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-3 space-y-2",
					children: verses.map((v) => v ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/poetry/$id",
						params: { id: v.id },
						className: "text-fg hover:underline",
						children: [v.title, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "text-muted",
							children: [" — ", getPoet(v.poetSlug)?.name]
						})]
					}) }, v.id) : null)
				})] }) : null,
				quotes.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-2xl",
					children: "Quotes"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-3 space-y-2",
					children: quotes.map((q) => q ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/quotes",
						className: "text-fg hover:underline",
						children: q.english
					}) }, q.id) : null)
				})] }) : null,
				stories.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-2xl",
					children: "Stories"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-3 space-y-2",
					children: stories.map((s) => s ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/stories/$slug",
						params: { slug: s.slug },
						className: "hover:underline",
						children: s.title
					}) }, s.slug) : null)
				})] }) : null,
				terms.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-2xl",
					children: "Terms"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-3 space-y-2",
					children: terms.map((t) => t ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/terms/$slug",
						params: { slug: t.slug },
						className: "hover:underline",
						children: t.term
					}) }, t.slug) : null)
				})] }) : null,
				qawwalis.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-2xl",
					children: "Qawwali"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-3 space-y-2",
					children: qawwalis.map((q) => q ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/qawwali/$id",
						params: { id: q.id },
						className: "hover:underline",
						children: q.title
					}) }, q.id) : null)
				})] }) : null,
				books.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-2xl",
					children: "Books"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-3 space-y-2",
					children: books.map((b) => b ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/ebooks/$slug",
						params: { slug: b.slug },
						className: "hover:underline",
						children: b.title
					}) }, b.slug) : null)
				})] }) : null
			]
		})
	})] });
}
//#endregion
export { FavoritesPage as component };
