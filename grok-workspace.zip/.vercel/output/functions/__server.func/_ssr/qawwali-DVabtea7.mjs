import { J as require_jsx_runtime, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { f as PageHead } from "./router-BRWYFOf0.mjs";
import { t as getPoet } from "./poets-Dez-ct4W.mjs";
import { d as qawwalis } from "./content-CcAZIJXZ.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/qawwali-DVabtea7.js
var import_jsx_runtime = require_jsx_runtime();
function QawwaliIndex() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative isolate overflow-hidden",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: "/images/lamp.jpg",
				alt: "",
				className: "h-56 w-full object-cover md:h-64"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-gradient-to-t from-bg via-bg/50 to-fg/30" })]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHead, {
			kicker: "Mehfil",
			title: "Qawwali lyrics",
			dek: "Traditional kalam still sung in the courtyards — not a concert, a liturgy of repetition."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mx-auto flex max-w-3xl flex-col gap-4 px-4 pb-16 md:px-6",
			children: qawwalis.map((q) => {
				const poet = q.poetSlug ? getPoet(q.poetSlug) : void 0;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/qawwali/$id",
					params: { id: q.id },
					className: "rounded-xl bg-surface p-6 shadow-[var(--shadow-border)] transition-shadow duration-fast hover:shadow-[var(--shadow-border-hover)]",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs uppercase tracking-wider text-subtle",
							children: q.language
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-1 font-display text-2xl",
							children: q.title
						}),
						poet ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm text-muted",
							children: poet.name
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 line-clamp-2 text-muted",
							children: q.english
						})
					]
				}, q.id);
			})
		})
	] });
}
//#endregion
export { QawwaliIndex as component };
