//#region node_modules/.nitro/vite/services/ssr/assets/poets-Dez-ct4W.js
var poets = [
	{
		slug: "rumi",
		name: "Jalaluddin Rumi",
		nameOriginal: "جلال‌الدین محمد رومی",
		nameHindi: "जलालुद्दीन रूमी",
		years: "1207 – 1273",
		place: "Konya",
		tradition: "Mevlevi",
		languages: ["Persian"],
		hue: "#2f4a44",
		bio: "Mawlana Jalaluddin Rumi was a scholar of Hanafi law who became, after meeting Shams of Tabriz, the great voice of love in Persian verse. His Masnavi-ye Ma'navi is a vast teaching poem of stories, jokes, and sudden illuminations; his Divan-e Shams burns with the bewilderment of the lover. The whirling ceremony of the Mevlevi order grew from the sama' he practiced in Konya."
	},
	{
		slug: "hafiz",
		name: "Hafiz Shirazi",
		nameOriginal: "خواجه شمس‌الدین محمد حافظ شیرازی",
		nameHindi: "हाफ़िज़ शीराज़ी",
		years: "c. 1315 – 1390",
		place: "Shiraz",
		tradition: "Lyric ghazal",
		languages: ["Persian"],
		hue: "#4a3b32",
		bio: "Khwaja Shamsuddin Muhammad Hafiz of Shiraz wrote ghazals so perfectly turned that they became a household oracle across the Persianate world. Wine, the Beloved's mole, the morning breeze, and the hypocrisy of the zahid are his instruments. To open a Divan-e-Hafiz at random is still, for many, a way of asking a question of the unseen."
	},
	{
		slug: "khusrau",
		name: "Amir Khusrau",
		nameOriginal: "ابوالحسن امیر خسرو دہلوی",
		nameHindi: "अमीर ख़ुसरो",
		years: "1253 – 1325",
		place: "Delhi",
		tradition: "Chishti",
		languages: ["Persian", "Hindavi"],
		hue: "#3d4f3a",
		bio: "Abul Hasan Yaminuddin Khusrau, the parrot of India, served five sultans and one saint. Disciple of Nizamuddin Auliya, he wrote in Persian and in the spoken Hindavi of Delhi, and is remembered as a father of qawwali. His riddles, dohas, and the kalam still sung at dargahs keep his voice in the courtyard."
	},
	{
		slug: "kabir",
		name: "Kabir",
		nameOriginal: "کبیر",
		nameHindi: "कबीर",
		years: "c. 1398 – 1518",
		place: "Kashi",
		tradition: "Sant / Nirguna",
		languages: ["Hindi"],
		hue: "#5a3f32",
		bio: "Kabir the weaver of Kashi spoke in a language that cut both temple and mosque. His dohas and ramainis refuse the comfort of caste, scripture-as-idol, and empty ritual. The Bijak and the verses kept in the Guru Granth Sahib still sound like a man at a loom, pulling one thread through pride and fear."
	},
	{
		slug: "bulleh-shah",
		name: "Bulleh Shah",
		nameOriginal: "سید عبداللہ شاہ قادری",
		nameHindi: "बुल्ले शाह",
		years: "1680 – 1757",
		place: "Kasur / Pandoke",
		tradition: "Qadiri / Punjabi kafi",
		languages: ["Punjabi"],
		hue: "#3a4450",
		bio: "Syed Abdullah Shah Qadri, called Bulleh Shah, took initiation from Inayat Shah Qadri and then spent a lifetime dismantling the scholar in himself. His kafis — Bulla ki jaana, Tere ishq nachaya — are sung from shrines to concert halls. He wrote as a man who had put the turban down and picked up the drum."
	},
	{
		slug: "baba-farid",
		name: "Baba Farid",
		nameOriginal: "فریدالدین مسعود گنج شکر",
		nameHindi: "बाबा फ़रीद",
		years: "c. 1173 – 1266",
		place: "Pakpattan",
		tradition: "Chishti",
		languages: ["Punjabi", "Persian"],
		hue: "#4a4034",
		bio: "Fariduddin Ganj-e-Shakar, the sugar-treasure of the Chishti silsila, settled at Ajodhan (Pakpattan) and made Punjabi a language of the path. His shlokas in the Guru Granth Sahib speak of the grave, the shrinking of days, and a humility so dry it glitters. He is the first great poet of Punjabi that the written record keeps."
	},
	{
		slug: "rabia",
		name: "Rabia al-Adawiyya",
		nameOriginal: "رابعة العدوية",
		nameHindi: "राबिया अल-अदविया",
		years: "c. 717 – 801",
		place: "Basra",
		tradition: "Early Sufi",
		languages: ["Arabic"],
		hue: "#4a3840",
		bio: "Rabia of Basra is remembered as the one who carried a torch and a jug of water — to burn Paradise and drown Hell — so that God might be loved for God's sake alone. A freedwoman and a teacher, she turned the early path from fear and bargain toward disinterested love. Her prayers survive as short, terrible, tender sentences."
	},
	{
		slug: "attar",
		name: "Fariduddin Attar",
		nameOriginal: "فریدالدین عطار نیشابوری",
		nameHindi: "फ़रीदुद्दीन अत्तार",
		years: "c. 1145 – 1221",
		place: "Nishapur",
		tradition: "Persian masnavi",
		languages: ["Persian"],
		hue: "#3f4634",
		bio: "Attar of Nishapur kept a pharmacy and wrote as if the whole created world were a shop of simples. The Conference of the Birds sends thirty birds across seven valleys toward the Simurgh; the Tadhkirat al-Awliya gathers the lives of the saints. Rumi called him and Sana'i the eyes with which he saw."
	},
	{
		slug: "saadi",
		name: "Saadi Shirazi",
		nameOriginal: "ابومحمد مصلح‌الدین سعدی شیرازی",
		nameHindi: "सादी शीराज़ी",
		years: "c. 1210 – 1292",
		place: "Shiraz",
		tradition: "Ethical verse",
		languages: ["Persian"],
		hue: "#3d4944",
		bio: "Muslihuddin Saadi wandered for decades — from Anatolia to India, the story goes — and came home to write the Gulistan and the Bustan, gardens of anecdote and counsel. His line on the children of Adam as limbs of one body is carved on a wall of the United Nations, but his true gift is a prose that walks like a friend."
	},
	{
		slug: "bhittai",
		name: "Shah Abdul Latif",
		nameOriginal: "شاه عبداللطيف ڀٽائي",
		nameHindi: "शाह अब्दुल लतीफ़ भिट्टाई",
		years: "1689 – 1752",
		place: "Bhit Shah",
		tradition: "Sindhi sur",
		languages: ["Sindhi"],
		hue: "#35504c",
		bio: "Shah Abdul Latif Bhittai gathered the folk heroines of Sindh — Sassui, Marui, Sohni, Leela — and made their wanderings a map of the soul. The Shah Jo Risalo is sung through the night on the tambura at his shrine. He wrote as a man sitting on a dune, listening to the desert and the river at once."
	},
	{
		slug: "sultan-bahu",
		name: "Sultan Bahu",
		nameOriginal: "سلطان باھو",
		nameHindi: "सुल्तान बाहू",
		years: "1630 – 1691",
		place: "Shorkot / Jhang",
		tradition: "Sarwari Qadiri",
		languages: ["Punjabi"],
		hue: "#4a4434",
		bio: "Sultan Bahu wrote more than a hundred Persian treatises, but the Punjabi abyat that end in the cry hoo are what the villages keep. Alif Allah chambe di booti is a planting of the Name in the heart. He taught that a book without tasting is a closed door, and tasting without a guide is a well without a rope."
	},
	{
		slug: "yunus-emre",
		name: "Yunus Emre",
		nameOriginal: "یونس امره",
		nameHindi: "यूनुस एम्रे",
		years: "c. 1238 – 1320",
		place: "Anatolia",
		tradition: "Turkish tekke",
		languages: ["Turkish"],
		hue: "#3a4a42",
		bio: "Yunus Emre made Anatolian Turkish a language of the path. His ilahis are sung in tekkes still: short, clear, almost folk, and then suddenly bottomless. Come, let us be friends for once, he says — a politics of the heart offered in a century of war."
	},
	{
		slug: "ibn-arabi",
		name: "Ibn Arabi",
		nameOriginal: "محيي الدين ابن عربي",
		nameHindi: "इब्न अरबी",
		years: "1165 – 1240",
		place: "Murcia / Damascus",
		tradition: "Akbari",
		languages: ["Arabic"],
		hue: "#3a4048",
		bio: "Muhyiddin Ibn Arabi, called al-Shaykh al-Akbar, wrote the Futuhat al-Makkiyya and the Fusus al-Hikam, a cosmology of the Perfect Human and the unity of being. His Tarjuman al-Ashwaq is a diwan of love-poems that he later interpreted as a lexicon of the path. He is difficult, inexhaustible, and still argued over in every generation."
	},
	{
		slug: "sachal",
		name: "Sachal Sarmast",
		nameOriginal: "سچل سرمست",
		nameHindi: "सचल सरमस्त",
		years: "1739 – 1827",
		place: "Daraza, Khairpur",
		tradition: "Sindhi / Sarmast",
		languages: [
			"Sindhi",
			"Seraiki",
			"Persian",
			"Urdu"
		],
		hue: "#4a3834",
		bio: "Abdul Wahab, called Sachal Sarmast — the truthful intoxicated one — wrote in seven languages from a small town in Sindh. He sang of unity with a bluntness that startled the orthodox and delighted the faqirs. His shrine at Daraza still fills with kafi and dhamal."
	},
	{
		slug: "lalon",
		name: "Lalon Fakir",
		nameOriginal: "লালন ফকির",
		nameHindi: "लालन फ़क़ीर",
		years: "c. 1774 – 1890",
		place: "Kushtia",
		tradition: "Baul",
		languages: ["Bengali"],
		hue: "#4a4038",
		bio: "Lalon Fakir of Cheuriya refused every caste-name offered to him. His songs ask who lives in this cage of bone, and whether the Lord is Hindu or Muslim, and then they laugh. The Baul path he embodies walks the fields with a one-string ektara and a theology of the body."
	},
	{
		slug: "waris-shah",
		name: "Waris Shah",
		nameOriginal: "وارث شاہ",
		nameHindi: "वारिस शाह",
		years: "1722 – 1798",
		place: "Jandiala Sher Khan",
		tradition: "Punjabi qissa",
		languages: ["Punjabi"],
		hue: "#3f463c",
		bio: "Waris Shah wrote Heer, the great Punjabi qissa of Heer and Ranjha, in 1766. It is a love story, a satire of the qazi and the clan, and a Sufi allegory in which the flute of Ranjha is the reed of the soul. To this day a recitation of Heer can still a courtyard."
	}
];
function getPoet(slug) {
	return poets.find((p) => p.slug === slug);
}
//#endregion
export { poets as n, getPoet as t };
