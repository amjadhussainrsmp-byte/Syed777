import { J as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { f as PageHead } from "./router-BRWYFOf0.mjs";
import { n as poets } from "./poets-Dez-ct4W.mjs";
import { t as PoetCard } from "./poet-card-B1I16-Eh.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/poets-CSSG6VCt.js
var import_jsx_runtime = require_jsx_runtime();
function PoetsIndex() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHead, {
		kicker: "The company",
		title: "Poets",
		dek: "Sixteen voices of the path — from Basra and Konya to Kashi, Kasur, and Bhit Shah."
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "mx-auto grid max-w-6xl gap-4 px-4 pb-16 sm:grid-cols-2 lg:grid-cols-3 md:px-6",
		children: poets.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PoetCard, { poet: p }, p.slug))
	})] });
}
//#endregion
export { PoetsIndex as component };
