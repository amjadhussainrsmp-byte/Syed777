import { J as require_jsx_runtime, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { f as PageHead, g as Ornament } from "./router-BRWYFOf0.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/about-BSDSGVid.js
var import_jsx_runtime = require_jsx_runtime();
function AboutPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto max-w-2xl px-4 pb-16",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHead, {
				kicker: "The room",
				title: "About Noornama",
				dek: "A reading-room of Sufi poetry, sant vani, and the old stories — named for noor, the light the poets kept talking about."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ornament, { className: "mb-10" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-5 text-lg leading-relaxed text-ink-soft",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Noornama is built in the spirit of the great public libraries of kalam: a place to read, not to replace a murshid, a mehfil, or a shrine. The verses here are from poets long in the public domain. The English is a new rendering for this room, not a claim to be the last word." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "You can switch scripts — original, Hindi, Roman, English — the way a reader in the subcontinent often keeps several mouths for one line. Saved items stay in this browser. There is no account." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
						"If a line stays with you, take it. If you want the drum, go sit in a courtyard.",
						" ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/poetry",
							className: "text-primary underline-offset-4 hover:underline",
							children: "Start with the poetry"
						}),
						"."
					] })
				]
			})
		]
	});
}
//#endregion
export { AboutPage as component };
