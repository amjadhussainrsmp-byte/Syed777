import { J as require_jsx_runtime, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as cn, t as Button } from "./button-CJlkzDbB.mjs";
import { s as ArrowRight } from "../_libs/lucide-react.mjs";
import { t as getPoet } from "./poets-Dez-ct4W.mjs";
import { d as qawwalis, h as todaysQuote, m as terms, n as ebooks, p as stories, t as articles, u as places } from "./content-CcAZIJXZ.mjs";
import { n as VerseBlock } from "./verse-block-Bu6x1CUL.mjs";
import { t as PoetCard } from "./poet-card-B1I16-Eh.mjs";
import { t as Badge } from "./badge-Cr0l7nxv.mjs";
import { i as todaysVerse, n as featuredPoets, t as counts } from "./catalog-CoRwg8Q9.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-1ZQbdRBT.js
var import_jsx_runtime = require_jsx_runtime();
function Section({ kicker, title, action, href, children, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: cn("mx-auto max-w-6xl px-4 py-14 md:px-6", className),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-8 flex items-end justify-between gap-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [kicker ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-medium uppercase tracking-[0.22em] text-subtle",
				children: kicker
			}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mt-2 font-display text-3xl tracking-tight md:text-4xl",
				children: title
			})] }), href && action ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: href,
				className: "shrink-0 text-sm text-primary hover:underline",
				children: action
			}) : null]
		}), children]
	});
}
function Home() {
	const verse = todaysVerse();
	const poet = getPoet(verse.poetSlug);
	const quote = todaysQuote();
	const quotePoet = getPoet(quote.poetSlug);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "relative isolate overflow-hidden",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: "/images/courtyard.jpg",
					alt: "A quiet marble courtyard at dusk, lamps hanging in the arches",
					className: "h-[min(78vh,640px)] w-full object-cover"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-gradient-to-t from-bg via-bg/55 to-fg/25" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "absolute inset-x-0 bottom-0 mx-auto max-w-6xl px-4 pb-10 md:px-6 md:pb-14",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-medium uppercase tracking-[0.24em] text-primary-fg/90",
							children: "Today's light"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "mt-3 max-w-3xl font-display text-4xl leading-[1.05] text-primary-fg md:text-6xl",
							children: "A library of Sufi poetry and the old names of love."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 max-w-xl text-base text-primary-fg/80 md:text-lg",
							children: "Read kalam in the original, in Hindi, in Roman, and in English. Keep a shelf of what stays with you."
						})
					]
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "mx-auto -mt-8 max-w-6xl px-4 md:-mt-12 md:px-6",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "rise-in rounded-xl bg-surface p-6 shadow-[var(--shadow-border)] md:p-10",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-center justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-medium uppercase tracking-[0.22em] text-subtle",
							children: "Verse of the day"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
							variant: "soft",
							children: verse.form
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-6",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VerseBlock, { verse })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-8 flex flex-wrap items-center justify-between gap-3 border-t border-border pt-6",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-sm text-muted",
							children: [poet ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/poets/$slug",
								params: { slug: poet.slug },
								className: "text-fg hover:underline",
								children: poet.name
							}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-subtle",
								children: [" · ", verse.title]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							asChild: true,
							variant: "outline",
							size: "sm",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: "/poetry/$id",
								params: { id: verse.id },
								children: ["Read the verse", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-4" })]
							})
						})]
					})
				]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, {
			kicker: "The company",
			title: "Featured poets",
			action: "All poets",
			href: "/poets",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-4 sm:grid-cols-2 lg:grid-cols-3",
				children: featuredPoets().map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PoetCard, { poet: p }, p.slug))
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "bg-bg-deep",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto grid max-w-6xl gap-0 px-4 py-14 md:grid-cols-2 md:px-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/poetry",
					search: { collection: "sufi-kalam" },
					className: "group rounded-xl p-8 transition-colors duration-fast hover:bg-surface md:rounded-l-xl md:rounded-r-none",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs uppercase tracking-[0.22em] text-subtle",
							children: "Collection"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-3 font-display text-3xl",
							children: "Sufi kalam"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 max-w-md text-muted",
							children: "Ghazal, kafi, masnavi, and the verses still sung in sama — Rumi, Hafiz, Khusrau, Bulleh Shah."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "mt-6 inline-flex items-center gap-2 text-sm text-primary",
							children: ["Enter the kalam ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-4 transition-transform group-hover:translate-x-0.5" })]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/poetry",
					search: { collection: "sant-vani" },
					className: "group rounded-xl p-8 transition-colors duration-fast hover:bg-surface md:rounded-r-xl md:rounded-l-none",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs uppercase tracking-[0.22em] text-subtle",
							children: "Collection"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-3 font-display text-3xl",
							children: "Sant vani"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 max-w-md text-muted",
							children: "Doha, shabad, and the blunt speech of the sants — Kabir, Farid, Lalon — cutting both temple and mosque."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "mt-6 inline-flex items-center gap-2 text-sm text-primary",
							children: ["Enter the vani ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-4 transition-transform group-hover:translate-x-0.5" })]
						})
					]
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Section, {
			kicker: "Today's saying",
			title: "A line to carry",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("blockquote", {
					className: "max-w-3xl font-display text-2xl leading-snug text-fg md:text-3xl",
					children: quote.english
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 text-sm text-muted",
					children: quotePoet?.name
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					asChild: true,
					variant: "link",
					className: "mt-2 px-0",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/quotes",
						children: "More quotes"
					})
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, {
			kicker: "The lexicon",
			title: "Sufi terms",
			action: "All terms",
			href: "/terms",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-3 sm:grid-cols-2 lg:grid-cols-4",
				children: terms.slice(0, 8).map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/terms/$slug",
					params: { slug: t.slug },
					className: "rounded-lg bg-surface p-5 shadow-[var(--shadow-border)] transition-shadow duration-fast hover:shadow-[var(--shadow-border-hover)]",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-display text-xl",
							children: t.term
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 font-nastaliq text-lg leading-none text-muted",
							dir: "rtl",
							children: t.urdu
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-sm text-muted",
							children: t.meaning
						})
					]
				}, t.slug))
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "relative isolate overflow-hidden",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: "/images/lamp.jpg",
					alt: "A brass lamp burning against a dark ground",
					className: "h-72 w-full object-cover md:h-80"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-fg/55" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "absolute inset-0 mx-auto flex max-w-6xl flex-col justify-center px-4 md:px-6",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs uppercase tracking-[0.22em] text-primary-fg/80",
							children: "Qawwali lyrics"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-3 max-w-xl font-display text-3xl text-primary-fg md:text-4xl",
							children: "Words still sung in the courtyard."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-3 max-w-lg text-sm text-primary-fg/80",
							children: [qawwalis.length, " kalams — Man kunto maula, Chhap tilak, Dama dam mast qalandar."]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							asChild: true,
							className: "mt-6 w-fit",
							variant: "secondary",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/qawwali",
								children: "Open the lyrics"
							})
						})
					]
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, {
			kicker: "Thresholds",
			title: "Dargah and urs",
			action: "All places",
			href: "/places",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-4 md:grid-cols-3",
				children: places.slice(0, 3).map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/places/$slug",
					params: { slug: p.slug },
					className: "overflow-hidden rounded-xl bg-surface shadow-[var(--shadow-border)] transition-shadow duration-fast hover:shadow-[var(--shadow-border-hover)]",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "p-5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs uppercase tracking-wider text-subtle",
								children: p.city
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "mt-1 font-display text-2xl",
								children: p.name
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm text-muted",
								children: p.summary
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-4 text-xs text-subtle",
								children: ["Urs · ", p.urs]
							})
						]
					})
				}, p.slug))
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "mx-auto grid max-w-6xl gap-4 px-4 pb-4 md:grid-cols-4 md:px-6",
			children: [
				{
					n: counts.stories,
					label: "Stories",
					to: "/stories"
				},
				{
					n: counts.quotes,
					label: "Quotes",
					to: "/quotes"
				},
				{
					n: counts.articles,
					label: "Articles",
					to: "/articles"
				},
				{
					n: counts.ebooks,
					label: "E-books",
					to: "/ebooks"
				}
			].map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: c.to,
				className: "rounded-xl bg-bg-deep px-5 py-6 text-center transition-colors duration-fast hover:bg-surface",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-4xl tabular-nums",
					children: c.n
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted",
					children: c.label
				})]
			}, c.label))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, {
			kicker: "Told in the dark",
			title: "Sufi stories",
			action: "All stories",
			href: "/stories",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-4 md:grid-cols-2",
				children: stories.slice(0, 4).map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/stories/$slug",
					params: { slug: s.slug },
					className: "rounded-xl bg-surface p-6 shadow-[var(--shadow-border)] transition-shadow duration-fast hover:shadow-[var(--shadow-border-hover)]",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs uppercase tracking-wider text-subtle",
							children: s.source
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "mt-2 font-display text-2xl",
							children: s.title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-muted",
							children: s.dek
						})
					]
				}, s.slug))
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mx-auto grid max-w-6xl items-center gap-8 px-4 py-14 md:grid-cols-2 md:px-6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: "/images/manuscript.jpg",
				alt: "An open illuminated manuscript",
				className: "h-72 w-full rounded-xl object-cover shadow-[var(--shadow-border)]"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs uppercase tracking-[0.22em] text-subtle",
					children: "Library"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-2 font-display text-3xl md:text-4xl",
					children: "Open books"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-muted",
					children: "Excerpts from the Masnavi, the Divan of Hafiz, the Conference of the Birds, the Gulistan, Shah Jo Risalo, and the Bijak."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-5 space-y-2",
					children: ebooks.slice(0, 4).map((b) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/ebooks/$slug",
						params: { slug: b.slug },
						className: "text-sm hover:underline",
						children: [b.title, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "text-muted",
							children: [" — ", b.author]
						})]
					}) }, b.slug))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					asChild: true,
					variant: "outline",
					className: "mt-6",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/ebooks",
						children: "The whole shelf"
					})
				})
			] })]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "mx-auto max-w-6xl px-4 pb-16 md:px-6",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-xl bg-primary px-6 py-10 text-primary-fg md:px-10",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs uppercase tracking-[0.22em] text-primary-fg/70",
						children: "From the desk"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-2 font-display text-3xl",
						children: articles[0]?.title
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 max-w-2xl text-primary-fg/80",
						children: articles[0]?.dek
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						variant: "secondary",
						className: "mt-6",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/articles/$slug",
							params: { slug: articles[0]?.slug ?? "what-is-sama" },
							children: "Read the article"
						})
					})
				]
			})
		})
	] });
}
//#endregion
export { Home as component };
