import { J as require_jsx_runtime, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { f as PageHead } from "./router-BRWYFOf0.mjs";
import { m as terms } from "./content-CcAZIJXZ.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/terms-DUt8R5Nk.js
var import_jsx_runtime = require_jsx_runtime();
function TermsIndex() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHead, {
		kicker: "The lexicon",
		title: "Sufi terms",
		dek: "A short vocabulary for reading the kalam — fana, ishq, sama, urs — with the original scripts beside the meaning."
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "mx-auto grid max-w-6xl gap-3 px-4 pb-16 sm:grid-cols-2 lg:grid-cols-3 md:px-6",
		children: terms.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
			to: "/terms/$slug",
			params: { slug: t.slug },
			className: "rounded-xl bg-surface p-5 shadow-[var(--shadow-border)] transition-shadow duration-fast hover:shadow-[var(--shadow-border-hover)]",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-baseline justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-2xl",
						children: t.term
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-nastaliq text-lg text-muted",
						dir: "rtl",
						children: t.urdu
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 font-devanagari text-sm text-subtle",
					children: t.hindi
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-sm text-muted",
					children: t.meaning
				})
			]
		}, t.slug))
	})] });
}
//#endregion
export { TermsIndex as component };
