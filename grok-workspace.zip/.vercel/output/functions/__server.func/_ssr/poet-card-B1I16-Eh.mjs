import { J as require_jsx_runtime, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as cn } from "./button-CJlkzDbB.mjs";
import { r as versesByPoet } from "./verses-CeHcBRqB.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/poet-card-B1I16-Eh.js
var import_jsx_runtime = require_jsx_runtime();
function PoetMark({ poet, className }) {
	const initial = poet.name.replace("Jalaluddin ", "").replace("Amir ", "").charAt(0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("relative flex size-16 shrink-0 items-center justify-center rounded-xl", className),
		style: { background: poet.hue },
		"aria-hidden": true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
			viewBox: "0 0 40 40",
			className: "absolute inset-1 text-primary-fg/25",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "11",
				y: "11",
				width: "18",
				height: "18",
				fill: "none",
				stroke: "currentColor",
				strokeWidth: "1.2"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "11",
				y: "11",
				width: "18",
				height: "18",
				fill: "none",
				stroke: "currentColor",
				strokeWidth: "1.2",
				transform: "rotate(45 20 20)"
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "relative font-display text-2xl text-primary-fg",
			children: initial
		})]
	});
}
function PoetCard({ poet }) {
	const count = versesByPoet(poet.slug).length;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
		to: "/poets/$slug",
		params: { slug: poet.slug },
		className: "group flex gap-4 rounded-xl bg-surface p-4 shadow-[var(--shadow-border)] transition-[box-shadow,transform] duration-fast ease-smooth hover:shadow-[var(--shadow-border-hover)]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PoetMark, { poet }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "min-w-0",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "font-display text-xl leading-tight text-fg group-hover:text-primary",
					children: poet.name
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-1 text-sm text-muted",
					children: [
						poet.years,
						" · ",
						poet.place
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-2 text-xs uppercase tracking-wider text-subtle",
					children: [poet.tradition, count ? ` · ${count} verses` : ""]
				})
			]
		})]
	});
}
//#endregion
export { PoetMark as n, PoetCard as t };
