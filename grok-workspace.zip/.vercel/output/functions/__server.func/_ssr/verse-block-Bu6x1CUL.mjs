import { J as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as cn } from "./button-CJlkzDbB.mjs";
import { n as create, t as persist } from "../_libs/zustand.mjs";
import { p as useHydrated } from "./router-BRWYFOf0.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/verse-block-Bu6x1CUL.js
var import_jsx_runtime = require_jsx_runtime();
var SCRIPT_OPTIONS = [
	{
		id: "all",
		label: "All"
	},
	{
		id: "original",
		label: "Original"
	},
	{
		id: "hindi",
		label: "हिन्दी"
	},
	{
		id: "roman",
		label: "Roman"
	},
	{
		id: "english",
		label: "English"
	}
];
var useScriptMode = create()(persist((set) => ({
	mode: "all",
	setMode: (mode) => set({ mode })
}), { name: "noornama-script" }));
var rtlScripts = [
	"urdu",
	"persian",
	"arabic",
	"punjabi",
	"sindhi"
];
function OriginalText({ text, script, size = "lg" }) {
	const isRtl = rtlScripts.includes(script);
	const isIndic = script === "hindi";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: cn("whitespace-pre-line text-fg", isRtl && "font-nastaliq text-right", isIndic && "font-devanagari", !isRtl && !isIndic && "font-display", size === "lg" ? "text-2xl md:text-3xl" : "text-xl md:text-2xl"),
		dir: isRtl ? "rtl" : "ltr",
		lang: script === "persian" || script === "urdu" ? "ur" : void 0,
		children: text
	});
}
function VerseLines({ original, originalScript, hindi, roman, english, size = "lg" }) {
	const stored = useScriptMode((s) => s.mode);
	const mode = useHydrated() ? stored : "all";
	const show = (key) => mode === "all" || mode === key;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-5",
		children: [
			show("original") ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OriginalText, {
				text: original,
				script: originalScript,
				size
			}) : null,
			show("hindi") && hindi ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: cn("whitespace-pre-line font-devanagari text-ink-soft", size === "lg" ? "text-xl md:text-2xl" : "text-lg"),
				children: hindi
			}) : null,
			show("roman") && roman ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: cn("whitespace-pre-line font-display italic text-muted", size === "lg" ? "text-xl md:text-2xl" : "text-lg"),
				children: roman
			}) : null,
			show("english") ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: cn("whitespace-pre-line font-display text-ink-soft", size === "lg" ? "text-xl leading-snug md:text-2xl" : "text-lg leading-snug"),
				children: english
			}) : null
		]
	});
}
function VerseBlock({ verse, size = "lg" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VerseLines, {
		original: verse.original,
		originalScript: verse.originalScript,
		hindi: verse.hindi,
		roman: verse.roman,
		english: verse.english,
		size
	});
}
//#endregion
export { useScriptMode as i, VerseBlock as n, VerseLines as r, SCRIPT_OPTIONS as t };
