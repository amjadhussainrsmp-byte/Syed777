import { J as require_jsx_runtime, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { f as PageHead } from "./router-BRWYFOf0.mjs";
import { t as getPoet } from "./poets-Dez-ct4W.mjs";
import { f as quotes } from "./content-CcAZIJXZ.mjs";
import { t as FavoriteButton } from "./favorite-button-467Gt0dM.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/quotes-Be5Z6O9f.js
var import_jsx_runtime = require_jsx_runtime();
function QuotesPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHead, {
		kicker: "Sayings",
		title: "Quotes",
		dek: "Short lines from the same mouths that wrote the long poems — to carry, to copy, to keep."
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "mx-auto grid max-w-6xl gap-4 px-4 pb-16 md:grid-cols-2 md:px-6",
		children: quotes.map((q) => {
			const poet = getPoet(q.poetSlug);
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				id: q.id,
				className: "flex flex-col rounded-xl bg-surface p-6 shadow-[var(--shadow-border)]",
				children: [
					q.original ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mb-4 whitespace-pre-line font-nastaliq text-xl text-fg",
						dir: "rtl",
						children: q.original
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("blockquote", {
						className: "font-display text-2xl leading-snug",
						children: q.english
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-6 flex items-center justify-between gap-3",
						children: [poet ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/poets/$slug",
							params: { slug: poet.slug },
							className: "text-sm text-muted hover:underline",
							children: poet.name
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FavoriteButton, {
							kind: "quote",
							id: q.id
						})]
					})
				]
			}, q.id);
		})
	})] });
}
//#endregion
export { QuotesPage as component };
