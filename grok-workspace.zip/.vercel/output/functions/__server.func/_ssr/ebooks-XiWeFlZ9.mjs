import { J as require_jsx_runtime, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { f as PageHead } from "./router-BRWYFOf0.mjs";
import { n as ebooks } from "./content-CcAZIJXZ.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/ebooks-XiWeFlZ9.js
var import_jsx_runtime = require_jsx_runtime();
function EbooksIndex() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative isolate overflow-hidden",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: "/images/manuscript.jpg",
				alt: "",
				className: "h-56 w-full object-cover md:h-64"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-gradient-to-t from-bg via-bg/55 to-fg/20" })]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHead, {
			kicker: "The shelf",
			title: "E-books",
			dek: "Open a few pages of the old books. These are excerpts, not complete editions — a lamp, not a library card."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mx-auto grid max-w-6xl gap-4 px-4 pb-16 md:grid-cols-2 md:px-6",
			children: ebooks.map((b) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/ebooks/$slug",
				params: { slug: b.slug },
				className: "rounded-xl bg-surface p-6 shadow-[var(--shadow-border)] transition-shadow duration-fast hover:shadow-[var(--shadow-border-hover)]",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-xs uppercase tracking-wider text-subtle",
						children: [
							b.language,
							" · ",
							b.year
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-2 font-display text-2xl",
						children: b.title
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-muted",
						children: b.author
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-muted",
						children: b.summary
					})
				]
			}, b.slug))
		})
	] });
}
//#endregion
export { EbooksIndex as component };
