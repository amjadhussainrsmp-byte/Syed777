import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { J as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as Search } from "../_libs/lucide-react.mjs";
import { d as Route$16, f as PageHead, h as Input } from "./router-BRWYFOf0.mjs";
import { r as searchAll } from "./catalog-CoRwg8Q9.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/search-BKLlzK8i.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function SearchPage() {
	const { q } = Route$16.useSearch();
	const navigate = Route$16.useNavigate();
	const [value, setValue] = (0, import_react.useState)(q);
	(0, import_react.useEffect)(() => {
		setValue(q);
	}, [q]);
	const hits = (0, import_react.useMemo)(() => searchAll(q), [q]);
	function onSubmit(e) {
		e.preventDefault();
		navigate({ search: { q: value.trim() } });
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHead, {
		kicker: "Look",
		title: "Search",
		dek: "Poets, verses, quotes, stories, terms, qawwali, places, articles, books."
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-3xl px-4 pb-16 md:px-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit,
				className: "relative",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "pointer-events-none absolute left-4 top-1/2 size-4 -translate-y-1/2 text-subtle" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value,
					onChange: (e) => setValue(e.target.value),
					placeholder: "Try Rumi, fana, Chhap tilak, Ajmer",
					className: "h-12 pl-11",
					autoFocus: true,
					"aria-label": "Search Noornama"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 text-sm text-muted",
				children: q ? `${hits.length} result${hits.length === 1 ? "" : "s"} for “${q}”` : "Type a name, a word, a first line."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-6 divide-y divide-border rounded-xl bg-surface shadow-[var(--shadow-border)]",
				children: hits.map((h) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
					href: h.href,
					className: "block px-5 py-4 hover:bg-bg-deep",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs uppercase tracking-wider text-subtle",
							children: h.kind
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 font-display text-xl",
							children: h.title
						}),
						h.subtitle ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm text-muted",
							children: h.subtitle
						}) : null
					]
				}) }, h.href + h.title))
			})
		]
	})] });
}
//#endregion
export { SearchPage as component };
