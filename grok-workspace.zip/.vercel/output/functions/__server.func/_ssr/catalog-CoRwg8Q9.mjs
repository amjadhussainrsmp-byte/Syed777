import { n as poets, t as getPoet } from "./poets-Dez-ct4W.mjs";
import { d as qawwalis, f as quotes, g as todaysVerseIndex, m as terms, n as ebooks, p as stories, t as articles, u as places } from "./content-CcAZIJXZ.mjs";
import { n as verses } from "./verses-CeHcBRqB.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/catalog-CoRwg8Q9.js
function featuredPoets() {
	return poets.filter((p) => [
		"rumi",
		"hafiz",
		"khusrau",
		"kabir",
		"bulleh-shah",
		"rabia"
	].includes(p.slug));
}
function todaysVerse() {
	return verses[todaysVerseIndex() % verses.length] ?? verses[0];
}
function searchAll(raw) {
	const q = raw.trim().toLowerCase();
	if (q.length < 1) return [];
	const hits = [];
	const match = (...fields) => fields.some((f) => f && f.toLowerCase().includes(q));
	for (const p of poets) if (match(p.name, p.nameHindi, p.nameOriginal, p.place, p.tradition, p.bio)) hits.push({
		href: `/poets/${p.slug}`,
		kind: "Poet",
		title: p.name,
		subtitle: `${p.years} · ${p.place}`
	});
	for (const v of verses) {
		const poet = getPoet(v.poetSlug);
		if (match(v.title, v.original, v.hindi, v.roman, v.english, v.form, poet?.name)) hits.push({
			href: `/poetry/${v.id}`,
			kind: v.form,
			title: v.title,
			subtitle: poet?.name ?? ""
		});
	}
	for (const quote of quotes) {
		const poet = getPoet(quote.poetSlug);
		if (match(quote.english, quote.original, quote.roman, poet?.name)) hits.push({
			href: `/quotes#${quote.id}`,
			kind: "Quote",
			title: quote.english.slice(0, 88),
			subtitle: poet?.name ?? ""
		});
	}
	for (const s of stories) if (match(s.title, s.dek, s.source, ...s.body)) hits.push({
		href: `/stories/${s.slug}`,
		kind: "Story",
		title: s.title,
		subtitle: s.source
	});
	for (const t of terms) if (match(t.term, t.urdu, t.hindi, t.roman, t.meaning, t.longer)) hits.push({
		href: `/terms/${t.slug}`,
		kind: "Term",
		title: t.term,
		subtitle: t.meaning
	});
	for (const qw of qawwalis) if (match(qw.title, qw.original, qw.hindi, qw.roman, qw.english, qw.language)) hits.push({
		href: `/qawwali/${qw.id}`,
		kind: "Qawwali",
		title: qw.title,
		subtitle: qw.language
	});
	for (const p of places) if (match(p.name, p.city, p.saint, p.summary, ...p.body)) hits.push({
		href: `/places/${p.slug}`,
		kind: "Place",
		title: p.name,
		subtitle: p.city
	});
	for (const a of articles) if (match(a.title, a.dek, ...a.body)) hits.push({
		href: `/articles/${a.slug}`,
		kind: "Article",
		title: a.title,
		subtitle: a.dek
	});
	for (const e of ebooks) if (match(e.title, e.author, e.summary, ...e.excerpt)) hits.push({
		href: `/ebooks/${e.slug}`,
		kind: "Book",
		title: e.title,
		subtitle: e.author
	});
	return hits.slice(0, 40);
}
var counts = {
	poets: poets.length,
	verses: verses.length,
	quotes: quotes.length,
	stories: stories.length,
	terms: terms.length,
	qawwalis: qawwalis.length,
	places: places.length,
	articles: articles.length,
	ebooks: ebooks.length
};
//#endregion
export { todaysVerse as i, featuredPoets as n, searchAll as r, counts as t };
