import { J as require_jsx_runtime, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { f as PageHead } from "./router-BRWYFOf0.mjs";
import { p as stories } from "./content-CcAZIJXZ.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/stories-fNm1NfZi.js
var import_jsx_runtime = require_jsx_runtime();
function StoriesIndex() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHead, {
		kicker: "Told in the dark",
		title: "Stories",
		dek: "Teaching tales retold from Rumi, Attar, Rabia, and the anonymous dervish who looked for his key under the lamp."
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "mx-auto grid max-w-6xl gap-4 px-4 pb-16 md:grid-cols-2 md:px-6",
		children: stories.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
			to: "/stories/$slug",
			params: { slug: s.slug },
			className: "rounded-xl bg-surface p-6 shadow-[var(--shadow-border)] transition-shadow duration-fast hover:shadow-[var(--shadow-border-hover)]",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs uppercase tracking-wider text-subtle",
					children: s.source
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-2 font-display text-2xl",
					children: s.title
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-muted",
					children: s.dek
				})
			]
		}, s.slug))
	})] });
}
//#endregion
export { StoriesIndex as component };
