import { J as require_jsx_runtime, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { f as PageHead } from "./router-BRWYFOf0.mjs";
import { t as articles } from "./content-CcAZIJXZ.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/articles-Dg-PFj-s.js
var import_jsx_runtime = require_jsx_runtime();
function ArticlesIndex() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHead, {
		kicker: "From the desk",
		title: "Articles",
		dek: "Short readings on sama, the ghazal, the Chishti kitchen, and why these poets still work."
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "mx-auto flex max-w-3xl flex-col gap-4 px-4 pb-16 md:px-6",
		children: articles.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
			to: "/articles/$slug",
			params: { slug: a.slug },
			className: "rounded-xl bg-surface p-6 shadow-[var(--shadow-border)] transition-shadow duration-fast hover:shadow-[var(--shadow-border-hover)]",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-xs text-subtle",
					children: [a.minutes, " min read"]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-1 font-display text-2xl",
					children: a.title
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-muted",
					children: a.dek
				})
			]
		}, a.slug))
	})] });
}
//#endregion
export { ArticlesIndex as component };
