import { J as require_jsx_runtime, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { f as PageHead } from "./router-BRWYFOf0.mjs";
import { u as places } from "./content-CcAZIJXZ.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/places-D2xpWtrO.js
var import_jsx_runtime = require_jsx_runtime();
function PlacesIndex() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative isolate overflow-hidden",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: "/images/dome.jpg",
				alt: "A dome and minaret against twilight",
				className: "h-64 w-full object-cover md:h-80"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-gradient-to-t from-bg via-bg/40 to-fg/25" })]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHead, {
			kicker: "Thresholds",
			title: "Dargah and urs",
			dek: "Courtyards where the path kept a kitchen. Urs dates follow the lunar calendar unless noted."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mx-auto grid max-w-6xl gap-4 px-4 pb-16 md:grid-cols-2 md:px-6",
			children: places.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/places/$slug",
				params: { slug: p.slug },
				className: "rounded-xl bg-surface p-6 shadow-[var(--shadow-border)] transition-shadow duration-fast hover:shadow-[var(--shadow-border-hover)]",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs uppercase tracking-wider text-subtle",
						children: p.city
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-1 font-display text-2xl",
						children: p.name
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-muted",
						children: p.saint
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-muted",
						children: p.summary
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-4 text-xs text-subtle",
						children: ["Urs · ", p.urs]
					})
				]
			}, p.slug))
		})
	] });
}
//#endregion
export { PlacesIndex as component };
