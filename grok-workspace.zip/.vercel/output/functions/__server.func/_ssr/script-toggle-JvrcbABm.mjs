import { J as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as cn } from "./button-CJlkzDbB.mjs";
import { p as useHydrated } from "./router-BRWYFOf0.mjs";
import { i as useScriptMode, t as SCRIPT_OPTIONS } from "./verse-block-Bu6x1CUL.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/script-toggle-JvrcbABm.js
var import_jsx_runtime = require_jsx_runtime();
function ScriptToggle({ className }) {
	const stored = useScriptMode((s) => s.mode);
	const setMode = useScriptMode((s) => s.setMode);
	const mode = useHydrated() ? stored : "all";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("inline-flex flex-wrap items-center gap-1 rounded-lg bg-bg-deep p-1", className),
		role: "tablist",
		"aria-label": "Script",
		children: SCRIPT_OPTIONS.map((opt) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			role: "tab",
			"aria-selected": mode === opt.id,
			onClick: () => setMode(opt.id),
			className: cn("h-9 rounded-md px-3 text-sm transition-[background-color,color] duration-quick ease-smooth", mode === opt.id ? "bg-surface text-fg shadow-[var(--shadow-border)]" : "text-muted hover:text-fg"),
			children: opt.label
		}, opt.id))
	});
}
//#endregion
export { ScriptToggle as t };
