import { J as require_jsx_runtime, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as cn } from "./button-CJlkzDbB.mjs";
import { f as PageHead, s as Route$9 } from "./router-BRWYFOf0.mjs";
import { t as getPoet } from "./poets-Dez-ct4W.mjs";
import { n as VerseBlock } from "./verse-block-Bu6x1CUL.mjs";
import { t as ScriptToggle } from "./script-toggle-JvrcbABm.mjs";
import { n as verses } from "./verses-CeHcBRqB.mjs";
import { t as Badge } from "./badge-Cr0l7nxv.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/poetry-Dx7JtM7B.js
var import_jsx_runtime = require_jsx_runtime();
var FILTERS = [
	{
		id: "all",
		label: "All"
	},
	{
		id: "sufi-kalam",
		label: "Sufi kalam"
	},
	{
		id: "sant-vani",
		label: "Sant vani"
	}
];
function PoetryIndex() {
	const { collection = "all" } = Route$9.useSearch();
	const list = collection === "all" ? verses : verses.filter((v) => v.collection === collection);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHead, {
		kicker: "The verses",
		title: "Poetry",
		dek: "Ghazal, doha, kafi, masnavi, shabad — read in the original scripts, in Hindi, in Roman, and in English."
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto flex max-w-6xl flex-col gap-6 px-4 pb-16 md:px-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-col gap-4 md:flex-row md:items-center md:justify-between",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-wrap gap-2",
				children: FILTERS.map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/poetry",
					search: { collection: f.id },
					className: cn("flex h-10 items-center rounded-full px-4 text-sm", collection === f.id ? "bg-primary text-primary-fg" : "bg-bg-deep text-muted"),
					children: f.label
				}, f.id))
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScriptToggle, {})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex flex-col gap-4",
			children: list.map((v) => {
				const poet = getPoet(v.poetSlug);
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/poetry/$id",
					params: { id: v.id },
					className: "rounded-xl bg-surface p-6 shadow-[var(--shadow-border)] transition-shadow duration-fast hover:shadow-[var(--shadow-border-hover)]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-4 flex flex-wrap items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
							variant: "soft",
							children: v.form
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-sm text-muted",
							children: poet?.name
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VerseBlock, {
						verse: v,
						size: "md"
					})]
				}, v.id);
			})
		})]
	})] });
}
//#endregion
export { PoetryIndex as component };
