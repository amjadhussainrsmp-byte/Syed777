import { J as require_jsx_runtime, b as Link } from "./_libs/@tanstack/react-router+[...].mjs";
import { t as Button } from "./_ssr/button-CJlkzDbB.mjs";
import { c as ArrowLeft } from "./_libs/lucide-react.mjs";
import { l as Route$12 } from "./_ssr/router-BRWYFOf0.mjs";
import { i as getEbook } from "./_ssr/content-CcAZIJXZ.mjs";
import { t as FavoriteButton } from "./_ssr/favorite-button-467Gt0dM.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_slug-CntTzMvw.js
var import_jsx_runtime = require_jsx_runtime();
function EbookPage() {
	const { slug } = Route$12.useParams();
	const book = getEbook(slug);
	if (!book) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto max-w-2xl px-4 py-24 text-center",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "font-display text-3xl",
			children: "This book is not on the shelf"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			asChild: true,
			variant: "outline",
			className: "mt-6",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/ebooks",
				children: "The library"
			})
		})]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto max-w-2xl px-4 py-12 md:py-16",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/ebooks",
				className: "inline-flex h-11 items-center gap-2 text-sm text-muted hover:text-fg",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "size-4" }), " The library"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-8 flex items-start justify-between gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-xs uppercase tracking-[0.22em] text-subtle",
						children: [
							book.language,
							" · ",
							book.year
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-2 font-display text-4xl tracking-tight",
						children: book.title
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-muted",
						children: book.author
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FavoriteButton, {
					kind: "ebook",
					id: book.slug
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-6 text-lg text-ink-soft",
				children: book.summary
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-10 space-y-6 rounded-xl bg-surface p-6 shadow-[var(--shadow-border)] md:p-8",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs uppercase tracking-[0.22em] text-subtle",
					children: "Excerpt"
				}), book.excerpt.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-xl leading-relaxed",
					children: p
				}, p.slice(0, 24)))]
			})
		]
	});
}
//#endregion
export { EbookPage as component };
