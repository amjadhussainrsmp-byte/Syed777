import { J as require_jsx_runtime, b as Link } from "./_libs/@tanstack/react-router+[...].mjs";
import { t as Button } from "./_ssr/button-CJlkzDbB.mjs";
import { c as ArrowLeft } from "./_libs/lucide-react.mjs";
import { n as Route } from "./_ssr/router-BRWYFOf0.mjs";
import { l as getTerm } from "./_ssr/content-CcAZIJXZ.mjs";
import { t as FavoriteButton } from "./_ssr/favorite-button-467Gt0dM.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_slug-Bp40JlWj.js
var import_jsx_runtime = require_jsx_runtime();
function TermPage() {
	const { slug } = Route.useParams();
	const term = getTerm(slug);
	if (!term) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto max-w-2xl px-4 py-24 text-center",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "font-display text-3xl",
			children: "This term is not in the lexicon"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			asChild: true,
			variant: "outline",
			className: "mt-6",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/terms",
				children: "All terms"
			})
		})]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto max-w-2xl px-4 py-12 md:py-16",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/terms",
				className: "inline-flex h-11 items-center gap-2 text-sm text-muted hover:text-fg",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "size-4" }), " All terms"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-8 flex items-start justify-between gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "font-display text-4xl",
						children: term.term
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 font-nastaliq text-3xl text-fg",
						dir: "rtl",
						children: term.urdu
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2 font-devanagari text-xl text-muted",
						children: [
							term.hindi,
							" · ",
							term.roman
						]
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FavoriteButton, {
					kind: "term",
					id: term.slug
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-8 text-xl text-ink-soft",
				children: term.meaning
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-6 text-lg leading-relaxed text-muted",
				children: term.longer
			})
		]
	});
}
//#endregion
export { TermPage as component };
