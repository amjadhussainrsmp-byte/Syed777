//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-BRCxbdRd.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/$",
			"/about",
			"/favorites",
			"/quotes",
			"/search",
			"/articles/$slug",
			"/ebooks/$slug",
			"/places/$slug",
			"/poetry/$id",
			"/poets/$slug",
			"/qawwali/$id",
			"/stories/$slug",
			"/terms/$slug",
			"/articles/",
			"/ebooks/",
			"/places/",
			"/poetry/",
			"/poets/",
			"/qawwali/",
			"/stories/",
			"/terms/"
		],
		preloads: [
			"/assets/index-BRMNX-HY.js",
			"/assets/button-kG6iHs2L.js",
			"/assets/preload-helper-Bkv5O_zL.js",
			"/assets/useNavigate-CfrZ2bAV.js",
			"/assets/createLucideIcon-B2rWP2Nd.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BRMNX-HY.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-Dn8llQ2h.js",
			"/assets/arrow-right-CI0nmq9T.js",
			"/assets/poets-geh1M9KS.js",
			"/assets/content-BrJFcCdD.js",
			"/assets/catalog-MeXfLdxB.js",
			"/assets/poet-card-B9Smpmn8.js",
			"/assets/badge-DaTm-DpO.js",
			"/assets/verse-block-JvxoSOBG.js"
		]
	},
	"/$": {
		filePath: "/workspace/src/routes/$.tsx",
		children: void 0,
		preloads: ["/assets/_-Dj-Acs-5.js"]
	},
	"/about": {
		filePath: "/workspace/src/routes/about.tsx",
		children: void 0,
		preloads: ["/assets/about-ClkOyjTQ.js"]
	},
	"/favorites": {
		filePath: "/workspace/src/routes/favorites.tsx",
		children: void 0,
		preloads: [
			"/assets/favorites-AIz0YDau.js",
			"/assets/poets-geh1M9KS.js",
			"/assets/verses-BejgSmU9.js",
			"/assets/content-BrJFcCdD.js"
		]
	},
	"/quotes": {
		filePath: "/workspace/src/routes/quotes.tsx",
		children: void 0,
		preloads: [
			"/assets/quotes-G0-Abh6a.js",
			"/assets/poets-geh1M9KS.js",
			"/assets/content-BrJFcCdD.js",
			"/assets/favorite-button-CCiaIpwZ.js"
		]
	},
	"/search": {
		filePath: "/workspace/src/routes/search.tsx",
		children: void 0,
		preloads: ["/assets/search-D9BvMZ_k.js", "/assets/catalog-MeXfLdxB.js"]
	},
	"/articles/$slug": {
		filePath: "/workspace/src/routes/articles/$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/_slug-Vf2B7Tt_.js",
			"/assets/arrow-left-M8-2ngML.js",
			"/assets/content-BrJFcCdD.js"
		]
	},
	"/ebooks/$slug": {
		filePath: "/workspace/src/routes/ebooks/$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/_slug-C2WnQrwh.js",
			"/assets/arrow-left-M8-2ngML.js",
			"/assets/content-BrJFcCdD.js",
			"/assets/favorite-button-CCiaIpwZ.js"
		]
	},
	"/places/$slug": {
		filePath: "/workspace/src/routes/places/$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/_slug-B3YzwmPQ.js",
			"/assets/arrow-left-M8-2ngML.js",
			"/assets/content-BrJFcCdD.js"
		]
	},
	"/poetry/$id": {
		filePath: "/workspace/src/routes/poetry/$id.tsx",
		children: void 0,
		preloads: [
			"/assets/_id-BvRY0Los.js",
			"/assets/arrow-left-M8-2ngML.js",
			"/assets/arrow-right-CI0nmq9T.js",
			"/assets/poets-geh1M9KS.js",
			"/assets/verses-BejgSmU9.js",
			"/assets/favorite-button-CCiaIpwZ.js",
			"/assets/poet-card-B9Smpmn8.js",
			"/assets/badge-DaTm-DpO.js",
			"/assets/verse-block-JvxoSOBG.js",
			"/assets/script-toggle-DohKWfeQ.js"
		]
	},
	"/poets/$slug": {
		filePath: "/workspace/src/routes/poets/$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/_slug-xQ8prAOm.js",
			"/assets/arrow-left-M8-2ngML.js",
			"/assets/poets-geh1M9KS.js",
			"/assets/verses-BejgSmU9.js",
			"/assets/poet-card-B9Smpmn8.js",
			"/assets/badge-DaTm-DpO.js",
			"/assets/verse-block-JvxoSOBG.js",
			"/assets/script-toggle-DohKWfeQ.js"
		]
	},
	"/qawwali/$id": {
		filePath: "/workspace/src/routes/qawwali/$id.tsx",
		children: void 0,
		preloads: [
			"/assets/_id-CUnvrQnX.js",
			"/assets/arrow-left-M8-2ngML.js",
			"/assets/poets-geh1M9KS.js",
			"/assets/content-BrJFcCdD.js",
			"/assets/favorite-button-CCiaIpwZ.js",
			"/assets/verse-block-JvxoSOBG.js",
			"/assets/script-toggle-DohKWfeQ.js"
		]
	},
	"/stories/$slug": {
		filePath: "/workspace/src/routes/stories/$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/_slug-Cqll_4g9.js",
			"/assets/arrow-left-M8-2ngML.js",
			"/assets/content-BrJFcCdD.js",
			"/assets/favorite-button-CCiaIpwZ.js"
		]
	},
	"/terms/$slug": {
		filePath: "/workspace/src/routes/terms/$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/_slug-Cxw5aTgD.js",
			"/assets/arrow-left-M8-2ngML.js",
			"/assets/content-BrJFcCdD.js",
			"/assets/favorite-button-CCiaIpwZ.js"
		]
	},
	"/articles/": {
		filePath: "/workspace/src/routes/articles/index.tsx",
		children: void 0,
		preloads: ["/assets/articles-BaBwX8rb.js", "/assets/content-BrJFcCdD.js"]
	},
	"/ebooks/": {
		filePath: "/workspace/src/routes/ebooks/index.tsx",
		children: void 0,
		preloads: ["/assets/ebooks-C75VgMQ_.js", "/assets/content-BrJFcCdD.js"]
	},
	"/places/": {
		filePath: "/workspace/src/routes/places/index.tsx",
		children: void 0,
		preloads: ["/assets/places-zcH4ZFTT.js", "/assets/content-BrJFcCdD.js"]
	},
	"/poetry/": {
		filePath: "/workspace/src/routes/poetry/index.tsx",
		children: void 0,
		preloads: [
			"/assets/poetry-DvK70fBT.js",
			"/assets/poets-geh1M9KS.js",
			"/assets/verses-BejgSmU9.js",
			"/assets/badge-DaTm-DpO.js",
			"/assets/verse-block-JvxoSOBG.js",
			"/assets/script-toggle-DohKWfeQ.js"
		]
	},
	"/poets/": {
		filePath: "/workspace/src/routes/poets/index.tsx",
		children: void 0,
		preloads: [
			"/assets/poets-DUHRHIv7.js",
			"/assets/poets-geh1M9KS.js",
			"/assets/poet-card-B9Smpmn8.js"
		]
	},
	"/qawwali/": {
		filePath: "/workspace/src/routes/qawwali/index.tsx",
		children: void 0,
		preloads: [
			"/assets/qawwali-C1QK9CPF.js",
			"/assets/poets-geh1M9KS.js",
			"/assets/content-BrJFcCdD.js"
		]
	},
	"/stories/": {
		filePath: "/workspace/src/routes/stories/index.tsx",
		children: void 0,
		preloads: ["/assets/stories-B-HDsDfw.js", "/assets/content-BrJFcCdD.js"]
	},
	"/terms/": {
		filePath: "/workspace/src/routes/terms/index.tsx",
		children: void 0,
		preloads: ["/assets/terms-BMRBh4vz.js", "/assets/content-BrJFcCdD.js"]
	}
} });
//#endregion
export { tsrStartManifest };
