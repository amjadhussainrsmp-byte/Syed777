var e=[{id:`rumi-reed`,poetSlug:`rumi`,title:`Listen to the reed`,form:`masnavi`,collection:`sufi-kalam`,originalScript:`persian`,original:`بشنو از نی چون حکایت می‌کند
از جدایی‌ها شکایت می‌کند
کز نیستان تا مرا ببریده‌اند
در نفیرم مرد و زن نالیده‌اند`,hindi:`बश्नो अज़ ने चूँ हिकायत मीकुनाद
अज़ जुदाईहा शिकायत मीकुनाद
किज़ नेस्ताँ ता मरा बुर्रीदाअन्द
दर नफ़ीरम मर्द ओ ज़न नालीदाअन्द`,roman:`Beshno az ney chon hekaayat mikonad
Az jodaayi-ha shekaayat mikonad
Kaz neystaan ta maraa borride-and
Dar nafiram mard o zan nalide-and`,english:`Listen to the reed-flute, how it tells a tale, complaining of separations — saying, ever since I was parted from the reed-bed, my lament has made men and women moan.`,note:`The opening of the Masnavi-ye Ma'navi. The reed is the soul cut from its source.`},{id:`rumi-guest-house`,poetSlug:`rumi`,title:`The guest house`,form:`masnavi`,collection:`sufi-kalam`,originalScript:`persian`,original:`این ماندنِ غم در دلِ تو مهمان است
هر روز کسی نو از غیب می‌آید
خوش باش و درِ خانه را باز گذار`,hindi:`ये ग़म दिल में मेहमान है
हर रोज़ कोई नया ग़ैब से आता है
ख़ुश रह और घर का दरवाज़ा खुला रख`,roman:`In maanadan-e gham dar del-e to mehmaan ast
Har ruz kasi-ye now az ghayb mi-aayad
Khosh baash o dar-e khaane ra baaz gozaar`,english:`This remaining of sorrow in your heart is a guest. Every day someone new arrives from the unseen. Be glad, and leave the door of the house open.`},{id:`rumi-come`,poetSlug:`rumi`,title:`Come, come, whoever you are`,form:`rubai`,collection:`sufi-kalam`,originalScript:`persian`,original:`بازآ بازآ هر آنچه هستی بازآ
گر کافر و گبر و بت‌پرستی بازآ
این درگه ما درگه نومیدی نیست
صد بار اگر توبه شکستی بازآ`,hindi:`बाज़आ बाज़आ हर आँचे हस्ती बाज़आ
गर काफ़िर ओ गब्र ओ बुतपरस्ती बाज़आ
ईं दर्गह-ए मा दर्गह-ए नौमीदी नीस्त
सद बार अगर तौबा शिकस्ती बाज़आ`,roman:`Baaz-aa baaz-aa har aanche hasti baaz-aa
Gar kaafir o gabr o bot-parasti baaz-aa
In dargah-e maa dargah-e naumidi nist
Sad baar agar tauba shekasti baaz-aa`,english:`Come again, come again, whoever you are, come again — even if you are an unbeliever, a fire-worshipper, an idolater, come again. This doorway of ours is not a doorway of despair. If you have broken your repentance a hundred times, come again.`},{id:`hafiz-shirazi-turk`,poetSlug:`hafiz`,title:`If that Shirazi Turk`,form:`ghazal`,collection:`sufi-kalam`,originalScript:`persian`,original:`اگر آن ترک شیرازی به دست آرد دل ما را
به خال هندویش بخشم سمرقند و بخارا را`,hindi:`अगर आँ तर्क-ए-शीराज़ी ब दस्त आरद दिल-ए मा रा
ब ख़ाल-ए-हिंदूयश बख़्शम समरक़न्द ओ बुख़ारा रा`,roman:`Agar aan tork-e shirazi be dast aarad del-e maa ra
Be khaal-e hinduyash bakhsham samarqand o bokharaa ra`,english:`If that Shirazi Turk would take my heart into his hand, I would give Samarkand and Bukhara for the Hindu mole upon his cheek.`,note:`The most famous opening of the Divan. The Beloved's mole outweighs two imperial cities.`},{id:`hafiz-never-dies`,poetSlug:`hafiz`,title:`The heart made living by love`,form:`ghazal`,collection:`sufi-kalam`,originalScript:`persian`,original:`هرگز نمیرد آنکه دلش زنده شد به عشق
ثبت است بر جریدهٔ عالم دوام ما`,hindi:`हरगिज़ नमीरद आँके दिलश ज़िंदा शुद ब इश्क़
सबत अस्त बर जरीदा-ए आलम दवाम-ए मा`,roman:`Hargez namirad aanke delash zende shod be eshq
Sabt ast bar jaride-ye aalam davaam-e maa`,english:`The one whose heart has been made living by love never dies. Our permanence is written on the ledger of the world.`},{id:`khusrau-chhap`,poetSlug:`khusrau`,title:`Chhap tilak sab cheeni`,form:`qawwali`,collection:`sufi-kalam`,originalScript:`hindi`,original:`छाप तिलक सब छीनी रे मोसे नैन मिलाइके
प्रेम भटी का मदवा पिलाइके
मतवाली कर लीन्ही रे मोसे नैन मिलाइके`,hindi:`छाप तिलक सब छीनी रे मोसे नैन मिलाइके
प्रेम भटी का मदवा पिलाइके
मतवाली कर लीन्ही रे मोसे नैन मिलाइके`,roman:`Chhap tilak sab cheeni re mose nain milaaike
Prem bhati ka madva pilaaike
Matwali kar linhi re mose nain milaaike`,english:`You snatched away my marks of caste and my forehead-mark, merely by meeting my eyes. You made me drink the wine of love's tavern, and made me drunk — merely by meeting my eyes.`,note:`Hindavi kalam sung as qawwali at the dargah of Nizamuddin. The 'you' is the murshid.`},{id:`khusrau-darya`,poetSlug:`khusrau`,title:`The river of love`,form:`doha`,collection:`sufi-kalam`,originalScript:`hindi`,original:`खुसरो दरिया प्रेम का, उलटी वा की धार
जो उतरा सो डूब गया, जो डूबा सो पार`,hindi:`खुसरो दरिया प्रेम का, उलटी वा की धार
जो उतरा सो डूब गया, जो डूबा सो पार`,roman:`Khusrau darya prem ka, ulti wa ki dhaar
Jo utra so doob gaya, jo dooba so paar`,english:`Khusrau, the river of love runs the wrong way. Whoever tries to stay dry is drowned. Whoever drowns, reaches the other shore.`},{id:`khusrau-rang`,poetSlug:`khusrau`,title:`Aaj rang hai`,form:`qawwali`,collection:`sufi-kalam`,originalScript:`hindi`,original:`आज रंग है री माँ, रंग है री
मेरे महबूब के घर रंग है री
मोहे पीर पायो निजामुद्दीन औलिया`,hindi:`आज रंग है री माँ, रंग है री
मेरे महबूब के घर रंग है री
मोहे पीर पायो निजामुद्दीन औलिया`,roman:`Aaj rang hai ri maa, rang hai ri
Mere mahboob ke ghar rang hai ri
Mohe pir paayo Nizamuddin Auliya`,english:`Today there is colour, mother, there is colour — colour in the house of my beloved. I have found my pir: Nizamuddin Auliya.`},{id:`kabir-dhoonde`,poetSlug:`kabir`,title:`Where do you search for me`,form:`bhajan`,collection:`sant-vani`,originalScript:`hindi`,original:`मोको कहाँ ढूँढे रे बंदे, मैं तो तेरे पास में
ना तीरथ में ना मूरत में, ना एकान्त निवास में
ना मंदिर में ना मस्जिद में, ना काबे कैलास में
मैं तो तेरे पास में बंदे, मैं तो तेरे पास में`,hindi:`मोको कहाँ ढूँढे रे बंदे, मैं तो तेरे पास में
ना तीरथ में ना मूरत में, ना एकान्त निवास में
ना मंदिर में ना मस्जिद में, ना काबे कैलास में`,roman:`Moko kahaan dhoondhe re bande, main to tere paas mein
Naa teerath mein naa moorat mein, naa ekaant nivaas mein
Naa mandir mein naa masjid mein, naa kaabe kailaas mein
Main to tere paas mein bande, main to tere paas mein`,english:`Where do you search for me, friend? I am here, beside you. Not in pilgrimage, not in an idol, not in a lonely hermitage. Not in the temple, not in the mosque, not in Kaaba or Kailash. I am here, beside you.`},{id:`kabir-kasturi`,poetSlug:`kabir`,title:`The musk is in the deer`,form:`doha`,collection:`sant-vani`,originalScript:`hindi`,original:`कस्तूरी कुंडल बसै, मृग ढूँढत बन माही
ज्यों घट घट राम हैं, दुनिया देखत नाही`,hindi:`कस्तूरी कुंडल बसै, मृग ढूँढत बन माही
ज्यों घट घट राम हैं, दुनिया देखत नाही`,roman:`Kasturi kundal basai, mrig dhoondhat ban maahi
Jyon ghat ghat ram hain, duniya dekhat naahi`,english:`Musk lives in the deer's own navel, and the deer hunts it through the forest. So Ram lives in every body, and the world does not see.`},{id:`kabir-guru`,poetSlug:`kabir`,title:`Guru and Gobind`,form:`doha`,collection:`sant-vani`,originalScript:`hindi`,original:`गुरु गोविंद दोऊ खड़े, काके लागूं पाँय
बलिहारी गुरु आपने, गोविंद दियो बताय`,hindi:`गुरु गोविंद दोऊ खड़े, काके लागूं पाँय
बलिहारी गुरु आपने, गोविंद दियो बताय`,roman:`Guru govind dou khade, kaake lagoon paay
Balihari guru aapne, govind diyo bataay`,english:`Guru and Gobind both stand before me — whose feet do I touch first? I offer myself to the guru, who showed me Gobind.`},{id:`bulleh-kaun`,poetSlug:`bulleh-shah`,title:`Bulla, what do I know of who I am`,form:`kafi`,collection:`sufi-kalam`,originalScript:`punjabi`,original:`بُلھا کی جاݨاں میں کون
نا میں مومن وچ مسجد ناں
نا میں وچ کفر دیاں ریناں
نا میں پاکاں وچ پلیاں
نا میں وچ پلیت حرام`,hindi:`बुल्ला की जाणा मैं कौन
ना मैं मोमिन विच मस्जिद नाँ
ना मैं विच कुफ़र दियाँ रीनाँ
ना मैं पाकाँ विच पलियाँ
ना मैं विच पलीत हराम`,roman:`Bulla ki jaana main kaun
Naa main momin vich masjid naan
Naa main vich kufr diyaan reenaan
Naa main paakaan vich paliyaan
Naa main vich paleet haraam`,english:`Bulla, what do I know of who I am? I am not the believer in the mosque, nor the dweller in the lanes of unbelief. I am not among the pure, nor among the filthy and forbidden.`},{id:`bulleh-ishq`,poetSlug:`bulleh-shah`,title:`Your love made me dance`,form:`kafi`,collection:`sufi-kalam`,originalScript:`punjabi`,original:`تیرے عشق نچایا کر تھیہ تھیہ
تھئی میں تیرا ہو، کر تھیہ تھیہ`,hindi:`तेरे इश्क़ नचाया कर थेया थेया
थई मैं तेरा हो, कर थेया थेया`,roman:`Tere ishq nachaya kar theya theya
Thayi main tera ho, kar theya theya`,english:`Your love made me dance — theya theya. I became yours. Theya theya.`},{id:`farid-days`,poetSlug:`baba-farid`,title:`The days dwindle`,form:`shabad`,collection:`sant-vani`,originalScript:`punjabi`,original:`فریدہ رنگی دنیا وگدی
دنیا وگدی جاے
اِک دوہے تے ورجن
کدی نہ آون جھاے`,hindi:`फ़रीदा रंगी दुनिया वगदी
दुनिया वगदी जाए
इक दोहे ते वरजन
कदी न आवन झाए`,roman:`Farida rangi duniya wagdi
Duniya wagdi jaaye
Ik dohe te varjan
Kadi na aavan jhaaye`,english:`Farid: this coloured world is flowing past, the world is flowing away. They warn one another with couplets — and still they never come home.`},{id:`farid-sweet`,poetSlug:`baba-farid`,title:`Make sweet the tongue`,form:`shabad`,collection:`sant-vani`,originalScript:`punjabi`,original:`فریدہ جے تُوں ماری نہی
کوئی نہ مارئے
آپڑے گھر جاگ فریدا
مت کوئی جاگئے`,hindi:`फ़रीदा जे तूँ मारे नहीं
कोई न मारए
आपड़े घर जाग फ़रीदा
मत कोई जागए`,roman:`Farida je toon maare nahi
Koi na maare
Aapde ghar jaag Farida
Mat koi jaage`,english:`Farid: if you do not strike, no one will strike you. Wake in your own house, Farid, lest someone else have to wake you.`},{id:`rabia-prayer`,poetSlug:`rabia`,title:`Not from fear, not from hope`,form:`nazm`,collection:`sufi-kalam`,originalScript:`arabic`,original:`اللهم إن كنت أعبدك خوفاً من نارك فاحرقني بها
وإن كنت أعبدك طمعاً في جنتك فاحرمنيها
وإن كنت أعبدك لوجهك الكريم فلا تحرمني منه`,hindi:`ऐ अल्लाह, अगर मैंने तुझे तेरी आग के डर से पूजा तो उसी में जला दे
और अगर मैंने तेरी जन्नत की लालच से पूजा तो उससे वंचित कर दे
और अगर मैंने तेरे ही सौन्दर्य के लिए पूजा तो उससे वंचित मत कर`,roman:`Allahumma in kuntu a'buduka khawfan min naarika fa-ahriqni biha
Wa in kuntu a'buduka tama'an fi jannatika fa-hrimniha
Wa in kuntu a'buduka li-wajhika al-karim fa-la tahrimni minhu`,english:`O God, if I have worshipped You from fear of Your fire, burn me in it. If I have worshipped You from desire of Your garden, withhold it from me. If I have worshipped You for the sake of Your noble face, do not withhold it from me.`},{id:`attar-moth`,poetSlug:`attar`,title:`The moth and the flame`,form:`masnavi`,collection:`sufi-kalam`,originalScript:`persian`,original:`یکی پروانه گفت از حال آتش
که آن سوزنده دارد تابش خوش
دگر گفتا نشان از نور دارم
سیم گفتا در او گم گشته‌ام من`,hindi:`एक पतंगा बोला: आग की चमक कितनी सुन्दर है
दूसरे ने कहा: मैं उसके प्रकाश की ख़बर लाया हूँ
तीसरे ने कहा: मैं उसी में खो गया हूँ`,roman:`Yeki parvaane goft az haal-e aatash
Ke aan suzande daarad taabesh-e khosh
Degar gofta neshaan az noor daaram
Sevom gofta dar u gom gashte-am man`,english:`One moth said of the fire: how lovely is that burning brightness. The second said: I bring news of its light. The third said: I am lost in it.`,note:`From the Conference of the Birds. Only the moth that is consumed has knowledge.`},{id:`saadi-bani-adam`,poetSlug:`saadi`,title:`The children of Adam`,form:`masnavi`,collection:`sufi-kalam`,originalScript:`persian`,original:`بنی آدم اعضای یک پیکرند
که در آفرینش ز یک گوهرند
چو عضوی به درد آورد روزگار
دگر عضوها را نماند قرار`,hindi:`बनी आदम आज़ा-ए यक पैकरन्द
कि दर आफ़रीनिश ज़ यक गौहरन्द
चू आज़्वी ब दर्द आवरद रोज़गार
दिगर अज़्वहा रा नमानद क़रार`,roman:`Bani aadam a'zaa-ye yek peykarand
Ke dar aafarinesh ze yek gowharand
Cho ozvi be dard aavarad ruzgaar
Degar ozvha ra namaanad qaraar`,english:`The children of Adam are limbs of one body, created of one essence. When fortune inflicts pain on one limb, the others cannot remain at rest.`},{id:`bhittai-sassui`,poetSlug:`bhittai`,title:`Sassui on the track`,form:`kafi`,collection:`sufi-kalam`,originalScript:`sindhi`,original:`ساٿ نه ٿيو پرين جو، سسئي ٿي وياڻي
پير پٿر تي لهن، اڃ به هلي وڃ`,hindi:`संग न रहा प्रीतम का, सस्सुई हुई पथिक
पाँव पत्थर पर लगे, फिर भी चलती जा`,roman:`Saath na thiyo pareen jo, Sassui thi vyaani
Pair pathar te lahan, ajh bhi hali wanj`,english:`The beloved's company is gone; Sassui has become a wanderer. The feet meet stone — still, keep walking.`,note:`From Sur Sassui. The heroine's search for Punhun is the seeker's search for the Friend.`},{id:`bahu-alif`,poetSlug:`sultan-bahu`,title:`Alif Allah, the jasmine plant`,form:`bait`,collection:`sufi-kalam`,originalScript:`punjabi`,original:`الف اللہ چمبے دی بوٹی مرشد من وچ لائی ہو
نفی اثبات دا پانی ملیا ہر رگے ہر جائی ہو`,hindi:`अलिफ़ अल्लाह चम्बे दी बूटी मुर्शिद मन विच लाई हू
नफ़ी इसबात दा पानी मिल्या हर रगे हर जाई हू`,roman:`Alif Allah chambe di booti, murshid man vich laai hoo
Nafi asbaat da paani milya, har rage har jaai hoo`,english:`Alif of Allah — a jasmine plant the murshid set in the heart, hoo. The water of negation and affirmation reached every vein, every place, hoo.`},{id:`yunus-friends`,poetSlug:`yunus-emre`,title:`Come, let us be friends`,form:`nazm`,collection:`sufi-kalam`,originalScript:`turkish`,original:`Gelin tanış olalım
İşi kolay kılalım
Sevelim sevilelim
Dünya kimseye kalmaz`,hindi:`आओ, एक-दूसरे को जानें
काम को आसान करें
प्रेम करें, प्रेम पाएँ
दुनिया किसी के पास नहीं रहती`,roman:`Gelin tanis olalim
Isi kolay kilalim
Sevelim sevilelim
Dunya kimseye kalmaz`,english:`Come, let us be friends for once. Let us make the work easy. Let us love and be loved. The world remains with no one.`},{id:`ibn-arabi-religion`,poetSlug:`ibn-arabi`,title:`The religion of love`,form:`ghazal`,collection:`sufi-kalam`,originalScript:`arabic`,original:`أدين بدين الحب أنى توجهت ركائبه
فالحب ديني وإيماني`,hindi:`मैं प्रेम के धर्म पर हूँ, जिधर उसके ऊँट चलें
प्रेम ही मेरा धर्म है, मेरा ईमान है`,roman:`Adeenu bi-deeni al-hubbi anna tawajjahat raka'ibuhu
Fa-l-hubbu deeni wa imani`,english:`I follow the religion of Love: whichever way Love's camels turn, that way is my religion and my faith.`,note:`From the Tarjuman al-Ashwaq.`},{id:`sachal-neither`,poetSlug:`sachal`,title:`Neither this nor that`,form:`kafi`,collection:`sufi-kalam`,originalScript:`sindhi`,original:`نه هندو نه مسلمان آهيان
نه مسجد نه مندر جو باندهو آهيان
سچل چوي ٿو پاڻ سڃاڻ`,hindi:`न हिंदू न मुसलमान हूँ
न मस्जिद न मंदिर का बंधुआ हूँ
सचल कहता है: अपने को पहचान`,roman:`Na hindu na musalman aahiyan
Na masjid na mandir jo bandho aahiyan
Sachal chaway tho paan sanjaan`,english:`I am neither Hindu nor Muslim. I am bound neither to mosque nor to temple. Sachal says: recognise your own self.`},{id:`lalon-caste`,poetSlug:`lalon`,title:`What is Lalon's caste`,form:`bhajan`,collection:`sant-vani`,originalScript:`hindi`,original:`सब लोके कहे ललन किजाति की
ललन कहे जाति का गोत्र का
देख ना पाय केउ`,hindi:`सब लोग कहते हैं, लालन किस जाति का
लालन कहता है जाति का गोत्र का
देख न पाया कोई`,roman:`Sab loke kahe Lalon ki jati ki
Lalon kahe jati ka gotra ka
Dekh na paaye keu`,english:`Everyone asks what caste Lalon is. Lalon says: of caste and clan, no one has seen a thing.`},{id:`waris-heer`,poetSlug:`waris-shah`,title:`Heer's opening`,form:`nazm`,collection:`sufi-kalam`,originalScript:`punjabi`,original:`عشق دی نوکری نہوں کیتی
جتھے عشق وسے اوتھے چوکھا
وارث شاہ آکھے ہیر سݨاواں`,hindi:`इश्क़ की नौकरी नहीं की जाती
जहाँ इश्क़ बसे वहाँ भरपूर
वारिस शाह कहे: हीर सुनाऊँ`,roman:`Ishq di naukri nahion kiti
Jithe ishq wase othe chokha
Waris Shah aakhe Heer sunaavaan`,english:`Love is not a service one takes employment in. Where love dwells, there is abundance. Waris Shah says: I will tell Heer.`}];function t(t){return e.find(e=>e.id===t)}function n(t){return e.filter(e=>e.poetSlug===t)}export{e as n,n as r,t};