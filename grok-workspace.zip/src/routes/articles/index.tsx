import { createFileRoute, Link } from "@tanstack/react-router";
import { PageHead } from "@/components/site-shell";
import { articles } from "@/lib/catalog";

export const Route = createFileRoute("/articles/")({ component: ArticlesIndex });

function ArticlesIndex() {
  return (
    <main>
      <PageHead
        kicker="From the desk"
        title="Articles"
        dek="Short readings on sama, the ghazal, the Chishti kitchen, and why these poets still work."
      />
      <div className="mx-auto flex max-w-3xl flex-col gap-4 px-4 pb-16 md:px-6">
        {articles.map((a) => (
          <Link
            key={a.slug}
            to="/articles/$slug"
            params={{ slug: a.slug }}
            className="rounded-xl bg-surface p-6 shadow-[var(--shadow-border)] transition-shadow duration-fast hover:shadow-[var(--shadow-border-hover)]"
          >
            <p className="text-xs text-subtle">{a.minutes} min read</p>
            <h2 className="mt-1 font-display text-2xl">{a.title}</h2>
            <p className="mt-2 text-muted">{a.dek}</p>
          </Link>
        ))}
      </div>
    </main>
  );
}
