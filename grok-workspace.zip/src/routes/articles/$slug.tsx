import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";
import { getArticle } from "@/lib/catalog";

export const Route = createFileRoute("/articles/$slug")({ component: ArticlePage });

function ArticlePage() {
  const { slug } = Route.useParams();
  const article = getArticle(slug);

  if (!article) {
    return (
      <main className="mx-auto max-w-2xl px-4 py-24 text-center">
        <h1 className="font-display text-3xl">This article is not on the desk</h1>
        <Button asChild variant="outline" className="mt-6">
          <Link to="/articles">All articles</Link>
        </Button>
      </main>
    );
  }

  return (
    <main className="mx-auto max-w-2xl px-4 py-12 md:py-16">
      <Link to="/articles" className="inline-flex h-11 items-center gap-2 text-sm text-muted hover:text-fg">
        <ArrowLeft className="size-4" /> All articles
      </Link>
      <p className="mt-8 text-xs text-subtle">{article.minutes} min read</p>
      <h1 className="mt-2 font-display text-4xl tracking-tight">{article.title}</h1>
      <p className="mt-4 text-lg text-muted">{article.dek}</p>
      <div className="mt-10 space-y-6 text-lg leading-relaxed text-ink-soft">
        {article.body.map((p) => (
          <p key={p.slice(0, 28)}>{p}</p>
        ))}
      </div>
    </main>
  );
}
