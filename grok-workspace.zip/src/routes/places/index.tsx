import { createFileRoute, Link } from "@tanstack/react-router";
import { PageHead } from "@/components/site-shell";
import { places } from "@/lib/catalog";

export const Route = createFileRoute("/places/")({ component: PlacesIndex });

function PlacesIndex() {
  return (
    <main>
      <div className="relative isolate overflow-hidden">
        <img
          src="/images/dome.jpg"
          alt="A dome and minaret against twilight"
          className="h-64 w-full object-cover md:h-80"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-bg via-bg/40 to-fg/25" />
      </div>
      <PageHead
        kicker="Thresholds"
        title="Dargah and urs"
        dek="Courtyards where the path kept a kitchen. Urs dates follow the lunar calendar unless noted."
      />
      <div className="mx-auto grid max-w-6xl gap-4 px-4 pb-16 md:grid-cols-2 md:px-6">
        {places.map((p) => (
          <Link
            key={p.slug}
            to="/places/$slug"
            params={{ slug: p.slug }}
            className="rounded-xl bg-surface p-6 shadow-[var(--shadow-border)] transition-shadow duration-fast hover:shadow-[var(--shadow-border-hover)]"
          >
            <p className="text-xs uppercase tracking-wider text-subtle">{p.city}</p>
            <h2 className="mt-1 font-display text-2xl">{p.name}</h2>
            <p className="mt-1 text-sm text-muted">{p.saint}</p>
            <p className="mt-3 text-muted">{p.summary}</p>
            <p className="mt-4 text-xs text-subtle">Urs · {p.urs}</p>
          </Link>
        ))}
      </div>
    </main>
  );
}
