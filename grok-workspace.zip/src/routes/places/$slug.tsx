import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";
import { getPlace } from "@/lib/catalog";

export const Route = createFileRoute("/places/$slug")({ component: PlacePage });

function PlacePage() {
  const { slug } = Route.useParams();
  const place = getPlace(slug);

  if (!place) {
    return (
      <main className="mx-auto max-w-2xl px-4 py-24 text-center">
        <h1 className="font-display text-3xl">This place is not on the map</h1>
        <Button asChild variant="outline" className="mt-6">
          <Link to="/places">All places</Link>
        </Button>
      </main>
    );
  }

  return (
    <main>
      <div className="relative isolate overflow-hidden">
        <img src="/images/dome.jpg" alt="" className="h-56 w-full object-cover md:h-72" />
        <div className="absolute inset-0 bg-gradient-to-t from-bg via-bg/45 to-fg/20" />
      </div>
      <div className="mx-auto max-w-2xl px-4 py-12 md:px-6">
        <Link to="/places" className="inline-flex h-11 items-center gap-2 text-sm text-muted hover:text-fg">
          <ArrowLeft className="size-4" /> All places
        </Link>
        <p className="mt-6 text-xs uppercase tracking-[0.22em] text-subtle">{place.city}</p>
        <h1 className="mt-2 font-display text-4xl tracking-tight">{place.name}</h1>
        <p className="mt-3 text-muted">
          {place.saint} · Urs {place.urs}
        </p>
        <div className="mt-8 space-y-5 text-lg leading-relaxed text-ink-soft">
          {place.body.map((p) => (
            <p key={p.slice(0, 24)}>{p}</p>
          ))}
        </div>
      </div>
    </main>
  );
}
