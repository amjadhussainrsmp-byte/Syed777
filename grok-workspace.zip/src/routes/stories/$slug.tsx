import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowLeft } from "lucide-react";
import { FavoriteButton } from "@/components/favorite-button";
import { Button } from "@/components/ui/button";
import { getStory } from "@/lib/catalog";

export const Route = createFileRoute("/stories/$slug")({ component: StoryPage });

function StoryPage() {
  const { slug } = Route.useParams();
  const story = getStory(slug);

  if (!story) {
    return (
      <main className="mx-auto max-w-2xl px-4 py-24 text-center">
        <h1 className="font-display text-3xl">This story is not on the shelf</h1>
        <Button asChild variant="outline" className="mt-6">
          <Link to="/stories">All stories</Link>
        </Button>
      </main>
    );
  }

  return (
    <main className="mx-auto max-w-2xl px-4 py-12 md:py-16">
      <Link to="/stories" className="inline-flex h-11 items-center gap-2 text-sm text-muted hover:text-fg">
        <ArrowLeft className="size-4" /> All stories
      </Link>
      <p className="mt-8 text-xs uppercase tracking-[0.22em] text-subtle">{story.source}</p>
      <div className="mt-3 flex items-start justify-between gap-4">
        <h1 className="font-display text-4xl tracking-tight">{story.title}</h1>
        <FavoriteButton kind="story" id={story.slug} />
      </div>
      <p className="mt-4 text-lg text-muted">{story.dek}</p>
      <div className="mt-10 space-y-6 text-lg leading-relaxed text-ink-soft">
        {story.body.map((p) => (
          <p key={p.slice(0, 24)}>{p}</p>
        ))}
      </div>
    </main>
  );
}
