import { createFileRoute, Link } from "@tanstack/react-router";
import { PageHead } from "@/components/site-shell";
import { stories } from "@/lib/catalog";

export const Route = createFileRoute("/stories/")({ component: StoriesIndex });

function StoriesIndex() {
  return (
    <main>
      <PageHead
        kicker="Told in the dark"
        title="Stories"
        dek="Teaching tales retold from Rumi, Attar, Rabia, and the anonymous dervish who looked for his key under the lamp."
      />
      <div className="mx-auto grid max-w-6xl gap-4 px-4 pb-16 md:grid-cols-2 md:px-6">
        {stories.map((s) => (
          <Link
            key={s.slug}
            to="/stories/$slug"
            params={{ slug: s.slug }}
            className="rounded-xl bg-surface p-6 shadow-[var(--shadow-border)] transition-shadow duration-fast hover:shadow-[var(--shadow-border-hover)]"
          >
            <p className="text-xs uppercase tracking-wider text-subtle">{s.source}</p>
            <h2 className="mt-2 font-display text-2xl">{s.title}</h2>
            <p className="mt-2 text-muted">{s.dek}</p>
          </Link>
        ))}
      </div>
    </main>
  );
}
