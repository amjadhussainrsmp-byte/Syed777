import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowLeft } from "lucide-react";
import { FavoriteButton } from "@/components/favorite-button";
import { Button } from "@/components/ui/button";
import { getTerm } from "@/lib/catalog";

export const Route = createFileRoute("/terms/$slug")({ component: TermPage });

function TermPage() {
  const { slug } = Route.useParams();
  const term = getTerm(slug);

  if (!term) {
    return (
      <main className="mx-auto max-w-2xl px-4 py-24 text-center">
        <h1 className="font-display text-3xl">This term is not in the lexicon</h1>
        <Button asChild variant="outline" className="mt-6">
          <Link to="/terms">All terms</Link>
        </Button>
      </main>
    );
  }

  return (
    <main className="mx-auto max-w-2xl px-4 py-12 md:py-16">
      <Link to="/terms" className="inline-flex h-11 items-center gap-2 text-sm text-muted hover:text-fg">
        <ArrowLeft className="size-4" /> All terms
      </Link>
      <div className="mt-8 flex items-start justify-between gap-4">
        <div>
          <h1 className="font-display text-4xl">{term.term}</h1>
          <p className="mt-2 font-nastaliq text-3xl text-fg" dir="rtl">
            {term.urdu}
          </p>
          <p className="mt-2 font-devanagari text-xl text-muted">
            {term.hindi} · {term.roman}
          </p>
        </div>
        <FavoriteButton kind="term" id={term.slug} />
      </div>
      <p className="mt-8 text-xl text-ink-soft">{term.meaning}</p>
      <p className="mt-6 text-lg leading-relaxed text-muted">{term.longer}</p>
    </main>
  );
}
