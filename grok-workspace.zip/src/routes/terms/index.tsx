import { createFileRoute, Link } from "@tanstack/react-router";
import { PageHead } from "@/components/site-shell";
import { terms } from "@/lib/catalog";

export const Route = createFileRoute("/terms/")({ component: TermsIndex });

function TermsIndex() {
  return (
    <main>
      <PageHead
        kicker="The lexicon"
        title="Sufi terms"
        dek="A short vocabulary for reading the kalam — fana, ishq, sama, urs — with the original scripts beside the meaning."
      />
      <div className="mx-auto grid max-w-6xl gap-3 px-4 pb-16 sm:grid-cols-2 lg:grid-cols-3 md:px-6">
        {terms.map((t) => (
          <Link
            key={t.slug}
            to="/terms/$slug"
            params={{ slug: t.slug }}
            className="rounded-xl bg-surface p-5 shadow-[var(--shadow-border)] transition-shadow duration-fast hover:shadow-[var(--shadow-border-hover)]"
          >
            <div className="flex items-baseline justify-between gap-3">
              <h2 className="font-display text-2xl">{t.term}</h2>
              <span className="font-nastaliq text-lg text-muted" dir="rtl">
                {t.urdu}
              </span>
            </div>
            <p className="mt-1 font-devanagari text-sm text-subtle">{t.hindi}</p>
            <p className="mt-3 text-sm text-muted">{t.meaning}</p>
          </Link>
        ))}
      </div>
    </main>
  );
}
