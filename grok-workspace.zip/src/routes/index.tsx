import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight } from "lucide-react";
import { PoetCard } from "@/components/poet-card";
import { Section } from "@/components/section";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { VerseBlock } from "@/components/verse-block";
import {
  articles,
  counts,
  ebooks,
  featuredPoets,
  getPoet,
  places,
  qawwalis,
  stories,
  terms,
  todaysQuote,
  todaysVerse,
} from "@/lib/catalog";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  const verse = todaysVerse();
  const poet = getPoet(verse.poetSlug);
  const quote = todaysQuote();
  const quotePoet = getPoet(quote.poetSlug);

  return (
    <main>
      <section className="relative isolate overflow-hidden">
        <img
          src="/images/courtyard.jpg"
          alt="A quiet marble courtyard at dusk, lamps hanging in the arches"
          className="h-[min(78vh,640px)] w-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-bg via-bg/55 to-fg/25" />
        <div className="absolute inset-x-0 bottom-0 mx-auto max-w-6xl px-4 pb-10 md:px-6 md:pb-14">
          <p className="text-xs font-medium uppercase tracking-[0.24em] text-primary-fg/90">
            Today's light
          </p>
          <h1 className="mt-3 max-w-3xl font-display text-4xl leading-[1.05] text-primary-fg md:text-6xl">
            A library of Sufi poetry and the old names of love.
          </h1>
          <p className="mt-4 max-w-xl text-base text-primary-fg/80 md:text-lg">
            Read kalam in the original, in Hindi, in Roman, and in English. Keep a shelf of what stays
            with you.
          </p>
        </div>
      </section>

      <section className="mx-auto -mt-8 max-w-6xl px-4 md:-mt-12 md:px-6">
        <article className="rise-in rounded-xl bg-surface p-6 shadow-[var(--shadow-border)] md:p-10">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <p className="text-xs font-medium uppercase tracking-[0.22em] text-subtle">Verse of the day</p>
            <Badge variant="soft">{verse.form}</Badge>
          </div>
          <div className="mt-6">
            <VerseBlock verse={verse} />
          </div>
          <div className="mt-8 flex flex-wrap items-center justify-between gap-3 border-t border-border pt-6">
            <p className="text-sm text-muted">
              {poet ? (
                <Link to="/poets/$slug" params={{ slug: poet.slug }} className="text-fg hover:underline">
                  {poet.name}
                </Link>
              ) : null}
              <span className="text-subtle"> · {verse.title}</span>
            </p>
            <Button asChild variant="outline" size="sm">
              <Link to="/poetry/$id" params={{ id: verse.id }}>
                Read the verse
                <ArrowRight className="size-4" />
              </Link>
            </Button>
          </div>
        </article>
      </section>

      <Section kicker="The company" title="Featured poets" action="All poets" href="/poets">
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {featuredPoets().map((p) => (
            <PoetCard key={p.slug} poet={p} />
          ))}
        </div>
      </Section>

      <section className="bg-bg-deep">
        <div className="mx-auto grid max-w-6xl gap-0 px-4 py-14 md:grid-cols-2 md:px-6">
          <Link
            to="/poetry"
            search={{ collection: "sufi-kalam" }}
            className="group rounded-xl p-8 transition-colors duration-fast hover:bg-surface md:rounded-l-xl md:rounded-r-none"
          >
            <p className="text-xs uppercase tracking-[0.22em] text-subtle">Collection</p>
            <h2 className="mt-3 font-display text-3xl">Sufi kalam</h2>
            <p className="mt-3 max-w-md text-muted">
              Ghazal, kafi, masnavi, and the verses still sung in sama — Rumi, Hafiz, Khusrau, Bulleh
              Shah.
            </p>
            <span className="mt-6 inline-flex items-center gap-2 text-sm text-primary">
              Enter the kalam <ArrowRight className="size-4 transition-transform group-hover:translate-x-0.5" />
            </span>
          </Link>
          <Link
            to="/poetry"
            search={{ collection: "sant-vani" }}
            className="group rounded-xl p-8 transition-colors duration-fast hover:bg-surface md:rounded-r-xl md:rounded-l-none"
          >
            <p className="text-xs uppercase tracking-[0.22em] text-subtle">Collection</p>
            <h2 className="mt-3 font-display text-3xl">Sant vani</h2>
            <p className="mt-3 max-w-md text-muted">
              Doha, shabad, and the blunt speech of the sants — Kabir, Farid, Lalon — cutting both
              temple and mosque.
            </p>
            <span className="mt-6 inline-flex items-center gap-2 text-sm text-primary">
              Enter the vani <ArrowRight className="size-4 transition-transform group-hover:translate-x-0.5" />
            </span>
          </Link>
        </div>
      </section>

      <Section kicker="Today's saying" title="A line to carry">
        <blockquote className="max-w-3xl font-display text-2xl leading-snug text-fg md:text-3xl">
          {quote.english}
        </blockquote>
        <p className="mt-4 text-sm text-muted">{quotePoet?.name}</p>
        <Button asChild variant="link" className="mt-2 px-0">
          <Link to="/quotes">More quotes</Link>
        </Button>
      </Section>

      <Section kicker="The lexicon" title="Sufi terms" action="All terms" href="/terms">
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          {terms.slice(0, 8).map((t) => (
            <Link
              key={t.slug}
              to="/terms/$slug"
              params={{ slug: t.slug }}
              className="rounded-lg bg-surface p-5 shadow-[var(--shadow-border)] transition-shadow duration-fast hover:shadow-[var(--shadow-border-hover)]"
            >
              <p className="font-display text-xl">{t.term}</p>
              <p className="mt-1 font-nastaliq text-lg leading-none text-muted" dir="rtl">
                {t.urdu}
              </p>
              <p className="mt-3 text-sm text-muted">{t.meaning}</p>
            </Link>
          ))}
        </div>
      </Section>

      <section className="relative isolate overflow-hidden">
        <img
          src="/images/lamp.jpg"
          alt="A brass lamp burning against a dark ground"
          className="h-72 w-full object-cover md:h-80"
        />
        <div className="absolute inset-0 bg-fg/55" />
        <div className="absolute inset-0 mx-auto flex max-w-6xl flex-col justify-center px-4 md:px-6">
          <p className="text-xs uppercase tracking-[0.22em] text-primary-fg/80">Qawwali lyrics</p>
          <h2 className="mt-3 max-w-xl font-display text-3xl text-primary-fg md:text-4xl">
            Words still sung in the courtyard.
          </h2>
          <p className="mt-3 max-w-lg text-sm text-primary-fg/80">
            {qawwalis.length} kalams — Man kunto maula, Chhap tilak, Dama dam mast qalandar.
          </p>
          <Button asChild className="mt-6 w-fit" variant="secondary">
            <Link to="/qawwali">Open the lyrics</Link>
          </Button>
        </div>
      </section>

      <Section kicker="Thresholds" title="Dargah and urs" action="All places" href="/places">
        <div className="grid gap-4 md:grid-cols-3">
          {places.slice(0, 3).map((p) => (
            <Link
              key={p.slug}
              to="/places/$slug"
              params={{ slug: p.slug }}
              className="overflow-hidden rounded-xl bg-surface shadow-[var(--shadow-border)] transition-shadow duration-fast hover:shadow-[var(--shadow-border-hover)]"
            >
              <div className="p-5">
                <p className="text-xs uppercase tracking-wider text-subtle">{p.city}</p>
                <h3 className="mt-1 font-display text-2xl">{p.name}</h3>
                <p className="mt-2 text-sm text-muted">{p.summary}</p>
                <p className="mt-4 text-xs text-subtle">Urs · {p.urs}</p>
              </div>
            </Link>
          ))}
        </div>
      </Section>

      <section className="mx-auto grid max-w-6xl gap-4 px-4 pb-4 md:grid-cols-4 md:px-6">
        {[
          { n: counts.stories, label: "Stories", to: "/stories" },
          { n: counts.quotes, label: "Quotes", to: "/quotes" },
          { n: counts.articles, label: "Articles", to: "/articles" },
          { n: counts.ebooks, label: "E-books", to: "/ebooks" },
        ].map((c) => (
          <Link
            key={c.label}
            to={c.to}
            className="rounded-xl bg-bg-deep px-5 py-6 text-center transition-colors duration-fast hover:bg-surface"
          >
            <p className="font-display text-4xl tabular-nums">{c.n}</p>
            <p className="mt-1 text-sm text-muted">{c.label}</p>
          </Link>
        ))}
      </section>

      <Section kicker="Told in the dark" title="Sufi stories" action="All stories" href="/stories">
        <div className="grid gap-4 md:grid-cols-2">
          {stories.slice(0, 4).map((s) => (
            <Link
              key={s.slug}
              to="/stories/$slug"
              params={{ slug: s.slug }}
              className="rounded-xl bg-surface p-6 shadow-[var(--shadow-border)] transition-shadow duration-fast hover:shadow-[var(--shadow-border-hover)]"
            >
              <p className="text-xs uppercase tracking-wider text-subtle">{s.source}</p>
              <h3 className="mt-2 font-display text-2xl">{s.title}</h3>
              <p className="mt-2 text-muted">{s.dek}</p>
            </Link>
          ))}
        </div>
      </Section>

      <section className="mx-auto grid max-w-6xl items-center gap-8 px-4 py-14 md:grid-cols-2 md:px-6">
        <img
          src="/images/manuscript.jpg"
          alt="An open illuminated manuscript"
          className="h-72 w-full rounded-xl object-cover shadow-[var(--shadow-border)]"
        />
        <div>
          <p className="text-xs uppercase tracking-[0.22em] text-subtle">Library</p>
          <h2 className="mt-2 font-display text-3xl md:text-4xl">Open books</h2>
          <p className="mt-3 text-muted">
            Excerpts from the Masnavi, the Divan of Hafiz, the Conference of the Birds, the Gulistan,
            Shah Jo Risalo, and the Bijak.
          </p>
          <ul className="mt-5 space-y-2">
            {ebooks.slice(0, 4).map((b) => (
              <li key={b.slug}>
                <Link to="/ebooks/$slug" params={{ slug: b.slug }} className="text-sm hover:underline">
                  {b.title}
                  <span className="text-muted"> — {b.author}</span>
                </Link>
              </li>
            ))}
          </ul>
          <Button asChild variant="outline" className="mt-6">
            <Link to="/ebooks">The whole shelf</Link>
          </Button>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-4 pb-16 md:px-6">
        <div className="rounded-xl bg-primary px-6 py-10 text-primary-fg md:px-10">
          <p className="text-xs uppercase tracking-[0.22em] text-primary-fg/70">From the desk</p>
          <h2 className="mt-2 font-display text-3xl">{articles[0]?.title}</h2>
          <p className="mt-3 max-w-2xl text-primary-fg/80">{articles[0]?.dek}</p>
          <Button asChild variant="secondary" className="mt-6">
            <Link to="/articles/$slug" params={{ slug: articles[0]?.slug ?? "what-is-sama" }}>
              Read the article
            </Link>
          </Button>
        </div>
      </section>
    </main>
  );
}
