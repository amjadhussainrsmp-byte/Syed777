import { createFileRoute } from "@tanstack/react-router";
import { Search as SearchIcon } from "lucide-react";
import { useEffect, useMemo, useState, type FormEvent } from "react";
import { PageHead } from "@/components/site-shell";
import { Input } from "@/components/ui/input";
import { searchAll } from "@/lib/catalog";

export const Route = createFileRoute("/search")({
  validateSearch: (s: Record<string, unknown>): { q: string } => ({
    q: typeof s.q === "string" ? s.q : "",
  }),
  component: SearchPage,
});

function SearchPage() {
  const { q } = Route.useSearch();
  const navigate = Route.useNavigate();
  const [value, setValue] = useState(q);

  useEffect(() => {
    setValue(q);
  }, [q]);

  const hits = useMemo(() => searchAll(q), [q]);

  function onSubmit(e: FormEvent) {
    e.preventDefault();
    void navigate({ search: { q: value.trim() } });
  }

  return (
    <main>
      <PageHead kicker="Look" title="Search" dek="Poets, verses, quotes, stories, terms, qawwali, places, articles, books." />
      <div className="mx-auto max-w-3xl px-4 pb-16 md:px-6">
        <form onSubmit={onSubmit} className="relative">
          <SearchIcon className="pointer-events-none absolute left-4 top-1/2 size-4 -translate-y-1/2 text-subtle" />
          <Input
            value={value}
            onChange={(e) => setValue(e.target.value)}
            placeholder="Try Rumi, fana, Chhap tilak, Ajmer"
            className="h-12 pl-11"
            autoFocus
            aria-label="Search Noornama"
          />
        </form>
        <p className="mt-4 text-sm text-muted">
          {q ? `${hits.length} result${hits.length === 1 ? "" : "s"} for “${q}”` : "Type a name, a word, a first line."}
        </p>
        <ul className="mt-6 divide-y divide-border rounded-xl bg-surface shadow-[var(--shadow-border)]">
          {hits.map((h) => (
            <li key={h.href + h.title}>
              <a href={h.href} className="block px-5 py-4 hover:bg-bg-deep">
                <p className="text-xs uppercase tracking-wider text-subtle">{h.kind}</p>
                <p className="mt-1 font-display text-xl">{h.title}</p>
                {h.subtitle ? <p className="mt-1 text-sm text-muted">{h.subtitle}</p> : null}
              </a>
            </li>
          ))}
        </ul>
      </div>
    </main>
  );
}
