import { createFileRoute, Link } from "@tanstack/react-router";
import { PageHead } from "@/components/site-shell";
import { getPoet, qawwalis } from "@/lib/catalog";

export const Route = createFileRoute("/qawwali/")({ component: QawwaliIndex });

function QawwaliIndex() {
  return (
    <main>
      <div className="relative isolate overflow-hidden">
        <img src="/images/lamp.jpg" alt="" className="h-56 w-full object-cover md:h-64" />
        <div className="absolute inset-0 bg-gradient-to-t from-bg via-bg/50 to-fg/30" />
      </div>
      <PageHead
        kicker="Mehfil"
        title="Qawwali lyrics"
        dek="Traditional kalam still sung in the courtyards — not a concert, a liturgy of repetition."
      />
      <div className="mx-auto flex max-w-3xl flex-col gap-4 px-4 pb-16 md:px-6">
        {qawwalis.map((q) => {
          const poet = q.poetSlug ? getPoet(q.poetSlug) : undefined;
          return (
            <Link
              key={q.id}
              to="/qawwali/$id"
              params={{ id: q.id }}
              className="rounded-xl bg-surface p-6 shadow-[var(--shadow-border)] transition-shadow duration-fast hover:shadow-[var(--shadow-border-hover)]"
            >
              <p className="text-xs uppercase tracking-wider text-subtle">{q.language}</p>
              <h2 className="mt-1 font-display text-2xl">{q.title}</h2>
              {poet ? <p className="mt-1 text-sm text-muted">{poet.name}</p> : null}
              <p className="mt-3 line-clamp-2 text-muted">{q.english}</p>
            </Link>
          );
        })}
      </div>
    </main>
  );
}
