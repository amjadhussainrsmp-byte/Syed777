import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowLeft } from "lucide-react";
import { FavoriteButton } from "@/components/favorite-button";
import { ScriptToggle } from "@/components/script-toggle";
import { Button } from "@/components/ui/button";
import { VerseLines } from "@/components/verse-block";
import { getPoet, getQawwali } from "@/lib/catalog";

export const Route = createFileRoute("/qawwali/$id")({ component: QawwaliPage });

function QawwaliPage() {
  const { id } = Route.useParams();
  const item = getQawwali(id);

  if (!item) {
    return (
      <main className="mx-auto max-w-2xl px-4 py-24 text-center">
        <h1 className="font-display text-3xl">This kalam is not on the shelf</h1>
        <Button asChild variant="outline" className="mt-6">
          <Link to="/qawwali">All qawwali</Link>
        </Button>
      </main>
    );
  }

  const poet = item.poetSlug ? getPoet(item.poetSlug) : undefined;

  return (
    <main className="mx-auto max-w-3xl px-4 py-12 md:py-16">
      <Link to="/qawwali" className="inline-flex h-11 items-center gap-2 text-sm text-muted hover:text-fg">
        <ArrowLeft className="size-4" /> All qawwali
      </Link>
      <div className="mt-8 flex items-start justify-between gap-4">
        <div>
          <p className="text-xs uppercase tracking-[0.22em] text-subtle">{item.language}</p>
          <h1 className="mt-2 font-display text-4xl tracking-tight">{item.title}</h1>
          {poet ? (
            <Link to="/poets/$slug" params={{ slug: poet.slug }} className="mt-2 inline-block text-sm text-muted hover:underline">
              {poet.name}
            </Link>
          ) : null}
        </div>
        <FavoriteButton kind="qawwali" id={item.id} />
      </div>
      <div className="mt-6">
        <ScriptToggle />
      </div>
      <article className="mt-8 rounded-xl bg-surface p-6 shadow-[var(--shadow-border)] md:p-10">
        <VerseLines
          original={item.original}
          originalScript={item.originalScript}
          hindi={item.hindi}
          roman={item.roman}
          english={item.english}
        />
      </article>
      <p className="mt-6 text-sm leading-relaxed text-muted">{item.note}</p>
    </main>
  );
}
