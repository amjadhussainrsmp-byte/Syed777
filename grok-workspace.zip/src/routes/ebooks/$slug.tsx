import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowLeft } from "lucide-react";
import { FavoriteButton } from "@/components/favorite-button";
import { Button } from "@/components/ui/button";
import { getEbook } from "@/lib/catalog";

export const Route = createFileRoute("/ebooks/$slug")({ component: EbookPage });

function EbookPage() {
  const { slug } = Route.useParams();
  const book = getEbook(slug);

  if (!book) {
    return (
      <main className="mx-auto max-w-2xl px-4 py-24 text-center">
        <h1 className="font-display text-3xl">This book is not on the shelf</h1>
        <Button asChild variant="outline" className="mt-6">
          <Link to="/ebooks">The library</Link>
        </Button>
      </main>
    );
  }

  return (
    <main className="mx-auto max-w-2xl px-4 py-12 md:py-16">
      <Link to="/ebooks" className="inline-flex h-11 items-center gap-2 text-sm text-muted hover:text-fg">
        <ArrowLeft className="size-4" /> The library
      </Link>
      <div className="mt-8 flex items-start justify-between gap-4">
        <div>
          <p className="text-xs uppercase tracking-[0.22em] text-subtle">
            {book.language} · {book.year}
          </p>
          <h1 className="mt-2 font-display text-4xl tracking-tight">{book.title}</h1>
          <p className="mt-2 text-muted">{book.author}</p>
        </div>
        <FavoriteButton kind="ebook" id={book.slug} />
      </div>
      <p className="mt-6 text-lg text-ink-soft">{book.summary}</p>
      <div className="mt-10 space-y-6 rounded-xl bg-surface p-6 shadow-[var(--shadow-border)] md:p-8">
        <p className="text-xs uppercase tracking-[0.22em] text-subtle">Excerpt</p>
        {book.excerpt.map((p) => (
          <p key={p.slice(0, 24)} className="font-display text-xl leading-relaxed">
            {p}
          </p>
        ))}
      </div>
    </main>
  );
}
