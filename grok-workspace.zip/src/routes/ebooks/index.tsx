import { createFileRoute, Link } from "@tanstack/react-router";
import { PageHead } from "@/components/site-shell";
import { ebooks } from "@/lib/catalog";

export const Route = createFileRoute("/ebooks/")({ component: EbooksIndex });

function EbooksIndex() {
  return (
    <main>
      <div className="relative isolate overflow-hidden">
        <img src="/images/manuscript.jpg" alt="" className="h-56 w-full object-cover md:h-64" />
        <div className="absolute inset-0 bg-gradient-to-t from-bg via-bg/55 to-fg/20" />
      </div>
      <PageHead
        kicker="The shelf"
        title="E-books"
        dek="Open a few pages of the old books. These are excerpts, not complete editions — a lamp, not a library card."
      />
      <div className="mx-auto grid max-w-6xl gap-4 px-4 pb-16 md:grid-cols-2 md:px-6">
        {ebooks.map((b) => (
          <Link
            key={b.slug}
            to="/ebooks/$slug"
            params={{ slug: b.slug }}
            className="rounded-xl bg-surface p-6 shadow-[var(--shadow-border)] transition-shadow duration-fast hover:shadow-[var(--shadow-border-hover)]"
          >
            <p className="text-xs uppercase tracking-wider text-subtle">
              {b.language} · {b.year}
            </p>
            <h2 className="mt-2 font-display text-2xl">{b.title}</h2>
            <p className="mt-1 text-sm text-muted">{b.author}</p>
            <p className="mt-3 text-muted">{b.summary}</p>
          </Link>
        ))}
      </div>
    </main>
  );
}
