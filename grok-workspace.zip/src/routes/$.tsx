import { createFileRoute, Link } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/$")({ component: NotFound });

function NotFound() {
  return (
    <main className="mx-auto max-w-lg px-4 py-24 text-center">
      <p className="text-xs uppercase tracking-[0.22em] text-subtle">Unwritten</p>
      <h1 className="mt-3 font-display text-4xl">This page is not on the shelf</h1>
      <p className="mt-4 text-muted">The lamp is lit in the courtyard. Come back through the door.</p>
      <Button asChild className="mt-8">
        <Link to="/">Home</Link>
      </Button>
    </main>
  );
}
