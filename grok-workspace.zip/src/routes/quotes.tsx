import { createFileRoute, Link } from "@tanstack/react-router";
import { FavoriteButton } from "@/components/favorite-button";
import { PageHead } from "@/components/site-shell";
import { getPoet, quotes } from "@/lib/catalog";

export const Route = createFileRoute("/quotes")({ component: QuotesPage });

function QuotesPage() {
  return (
    <main>
      <PageHead
        kicker="Sayings"
        title="Quotes"
        dek="Short lines from the same mouths that wrote the long poems — to carry, to copy, to keep."
      />
      <div className="mx-auto grid max-w-6xl gap-4 px-4 pb-16 md:grid-cols-2 md:px-6">
        {quotes.map((q) => {
          const poet = getPoet(q.poetSlug);
          return (
            <article
              id={q.id}
              key={q.id}
              className="flex flex-col rounded-xl bg-surface p-6 shadow-[var(--shadow-border)]"
            >
              {q.original ? (
                <p
                  className="mb-4 whitespace-pre-line font-nastaliq text-xl text-fg"
                  dir="rtl"
                >
                  {q.original}
                </p>
              ) : null}
              <blockquote className="font-display text-2xl leading-snug">{q.english}</blockquote>
              <div className="mt-6 flex items-center justify-between gap-3">
                {poet ? (
                  <Link to="/poets/$slug" params={{ slug: poet.slug }} className="text-sm text-muted hover:underline">
                    {poet.name}
                  </Link>
                ) : (
                  <span />
                )}
                <FavoriteButton kind="quote" id={q.id} />
              </div>
            </article>
          );
        })}
      </div>
    </main>
  );
}
