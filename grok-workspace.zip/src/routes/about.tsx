import { createFileRoute, Link } from "@tanstack/react-router";
import { Ornament } from "@/components/mark";
import { PageHead } from "@/components/site-shell";

export const Route = createFileRoute("/about")({ component: AboutPage });

function AboutPage() {
  return (
    <main className="mx-auto max-w-2xl px-4 pb-16">
      <PageHead
        kicker="The room"
        title="About Noornama"
        dek="A reading-room of Sufi poetry, sant vani, and the old stories — named for noor, the light the poets kept talking about."
      />
      <Ornament className="mb-10" />
      <div className="space-y-5 text-lg leading-relaxed text-ink-soft">
        <p>
          Noornama is built in the spirit of the great public libraries of kalam: a place to read, not to
          replace a murshid, a mehfil, or a shrine. The verses here are from poets long in the public
          domain. The English is a new rendering for this room, not a claim to be the last word.
        </p>
        <p>
          You can switch scripts — original, Hindi, Roman, English — the way a reader in the
          subcontinent often keeps several mouths for one line. Saved items stay in this browser. There
          is no account.
        </p>
        <p>
          If a line stays with you, take it. If you want the drum, go sit in a courtyard.{" "}
          <Link to="/poetry" className="text-primary underline-offset-4 hover:underline">
            Start with the poetry
          </Link>
          .
        </p>
      </div>
    </main>
  );
}
