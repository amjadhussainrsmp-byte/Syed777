import { createFileRoute, Link } from "@tanstack/react-router";
import { PageHead } from "@/components/site-shell";
import { Badge } from "@/components/ui/badge";
import { VerseBlock } from "@/components/verse-block";
import { ScriptToggle } from "@/components/script-toggle";
import { getPoet, verses } from "@/lib/catalog";
import type { CollectionId } from "@/lib/catalog/types";
import { cn } from "@/lib/utils";

type CollectionFilter = "all" | CollectionId;

export const Route = createFileRoute("/poetry/")({
  validateSearch: (s: Record<string, unknown>): { collection?: CollectionFilter } => {
    if (s.collection === "sant-vani" || s.collection === "sufi-kalam" || s.collection === "all") {
      return { collection: s.collection };
    }
    return {};
  },
  component: PoetryIndex,
});

const FILTERS: { id: CollectionFilter; label: string }[] = [
  { id: "all", label: "All" },
  { id: "sufi-kalam", label: "Sufi kalam" },
  { id: "sant-vani", label: "Sant vani" },
];

function PoetryIndex() {
  const { collection = "all" } = Route.useSearch();
  const list =
    collection === "all" ? verses : verses.filter((v) => v.collection === collection);

  return (
    <main>
      <PageHead
        kicker="The verses"
        title="Poetry"
        dek="Ghazal, doha, kafi, masnavi, shabad — read in the original scripts, in Hindi, in Roman, and in English."
      />
      <div className="mx-auto flex max-w-6xl flex-col gap-6 px-4 pb-16 md:px-6">
        <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
          <div className="flex flex-wrap gap-2">
            {FILTERS.map((f) => (
              <Link
                key={f.id}
                to="/poetry"
                search={{ collection: f.id }}
                className={cn(
                  "flex h-10 items-center rounded-full px-4 text-sm",
                  collection === f.id ? "bg-primary text-primary-fg" : "bg-bg-deep text-muted",
                )}
              >
                {f.label}
              </Link>
            ))}
          </div>
          <ScriptToggle />
        </div>
        <div className="flex flex-col gap-4">
          {list.map((v) => {
            const poet = getPoet(v.poetSlug);
            return (
              <Link
                key={v.id}
                to="/poetry/$id"
                params={{ id: v.id }}
                className="rounded-xl bg-surface p-6 shadow-[var(--shadow-border)] transition-shadow duration-fast hover:shadow-[var(--shadow-border-hover)]"
              >
                <div className="mb-4 flex flex-wrap items-center gap-2">
                  <Badge variant="soft">{v.form}</Badge>
                  <span className="text-sm text-muted">{poet?.name}</span>
                </div>
                <VerseBlock verse={v} size="md" />
              </Link>
            );
          })}
        </div>
      </div>
    </main>
  );
}
