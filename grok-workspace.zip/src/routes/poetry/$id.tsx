import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowLeft, ArrowRight, Share2 } from "lucide-react";
import { FavoriteButton } from "@/components/favorite-button";
import { PoetMark } from "@/components/poet-card";
import { ScriptToggle } from "@/components/script-toggle";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { VerseBlock } from "@/components/verse-block";
import { getPoet, getVerse, verses } from "@/lib/catalog";
import { useState } from "react";

export const Route = createFileRoute("/poetry/$id")({ component: VersePage });

function VersePage() {
  const { id } = Route.useParams();
  const verse = getVerse(id);
  const [copied, setCopied] = useState(false);

  if (!verse) {
    return (
      <main className="mx-auto max-w-2xl px-4 py-24 text-center">
        <h1 className="font-display text-3xl">This verse is not on the shelf</h1>
        <Button asChild variant="outline" className="mt-6">
          <Link to="/poetry">Back to poetry</Link>
        </Button>
      </main>
    );
  }

  const poet = getPoet(verse.poetSlug);
  const index = verses.findIndex((v) => v.id === verse.id);
  const prev = index > 0 ? verses[index - 1] : undefined;
  const next = index >= 0 && index < verses.length - 1 ? verses[index + 1] : undefined;
  const shareText = `${verse.title} — ${poet?.name ?? ""}\n${verse.english}`;

  async function share() {
    const url = window.location.href;
    try {
      await navigator.clipboard.writeText(`${shareText}\n${url}`);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1600);
    } catch {
      setCopied(false);
    }
  }

  return (
    <main className="mx-auto max-w-3xl px-4 py-12 md:px-6 md:py-16">
      <Link to="/poetry" className="inline-flex h-11 items-center gap-2 text-sm text-muted hover:text-fg">
        <ArrowLeft className="size-4" /> All poetry
      </Link>
      <div className="mt-8 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <Badge variant="outline" className="rounded-full">
            {verse.form}
          </Badge>
          <span className="text-sm text-subtle">{verse.collection === "sant-vani" ? "Sant vani" : "Sufi kalam"}</span>
        </div>
        <div className="flex items-center gap-2">
          <FavoriteButton kind="verse" id={verse.id} />
          <Button variant="outline" size="sm" onClick={() => void share()}>
            <Share2 className="size-4" />
            {copied ? "Copied" : "Share"}
          </Button>
        </div>
      </div>
      <h1 className="mt-6 font-display text-4xl tracking-tight">{verse.title}</h1>
      <div className="mt-6">
        <ScriptToggle />
      </div>
      <article className="mt-8 rounded-xl bg-surface p-6 shadow-[var(--shadow-border)] md:p-10">
        <VerseBlock verse={verse} />
      </article>
      {verse.note ? <p className="mt-6 text-sm leading-relaxed text-muted">{verse.note}</p> : null}
      {poet ? (
        <Link
          to="/poets/$slug"
          params={{ slug: poet.slug }}
          className="mt-10 flex items-center gap-4 rounded-xl bg-bg-deep p-4"
        >
          <PoetMark poet={poet} />
          <div>
            <p className="font-display text-xl">{poet.name}</p>
            <p className="text-sm text-muted">
              {poet.years} · {poet.place}
            </p>
          </div>
        </Link>
      ) : null}
      <div className="mt-12 flex items-center justify-between gap-4 border-t border-border pt-6">
        {prev ? (
          <Link to="/poetry/$id" params={{ id: prev.id }} className="text-sm text-muted hover:text-fg">
            <span className="flex items-center gap-1">
              <ArrowLeft className="size-4" /> Previous
            </span>
            <span className="mt-1 block font-display text-lg text-fg">{prev.title}</span>
          </Link>
        ) : (
          <span />
        )}
        {next ? (
          <Link to="/poetry/$id" params={{ id: next.id }} className="text-right text-sm text-muted hover:text-fg">
            <span className="flex items-center justify-end gap-1">
              Next <ArrowRight className="size-4" />
            </span>
            <span className="mt-1 block font-display text-lg text-fg">{next.title}</span>
          </Link>
        ) : null}
      </div>
    </main>
  );
}
