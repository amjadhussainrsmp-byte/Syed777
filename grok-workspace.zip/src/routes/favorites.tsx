import { createFileRoute, Link } from "@tanstack/react-router";
import { PageHead } from "@/components/site-shell";
import { Button } from "@/components/ui/button";
import {
  getEbook,
  getPoet,
  getQawwali,
  getQuote,
  getStory,
  getTerm,
  getVerse,
} from "@/lib/catalog";
import { useFavorites } from "@/lib/favorites";
import { useHydrated } from "@/lib/use-hydrated";

export const Route = createFileRoute("/favorites")({ component: FavoritesPage });

function FavoritesPage() {
  const hydrated = useHydrated();
  const items = useFavorites((s) => s.items);
  const total = Object.values(items).reduce((n, arr) => n + arr.length, 0);

  if (!hydrated) {
    return (
      <main>
        <PageHead kicker="Your shelf" title="Saved" dek="Kept in this browser only — a private margin, not an account." />
      </main>
    );
  }

  const verses = items.verse.map(getVerse).filter(Boolean);
  const quotes = items.quote.map(getQuote).filter(Boolean);
  const stories = items.story.map(getStory).filter(Boolean);
  const terms = items.term.map(getTerm).filter(Boolean);
  const qawwalis = items.qawwali.map(getQawwali).filter(Boolean);
  const books = items.ebook.map(getEbook).filter(Boolean);

  return (
    <main>
      <PageHead
        kicker="Your shelf"
        title="Saved"
        dek="Kept in this browser only — a private margin, not an account."
      />
      <div className="mx-auto max-w-3xl px-4 pb-16 md:px-6">
        {total === 0 ? (
          <div className="rounded-xl bg-surface px-6 py-12 text-center shadow-[var(--shadow-border)]">
            <p className="font-display text-2xl">The shelf is empty</p>
            <p className="mt-2 text-muted">Save a verse, a quote, a story — it stays on this device.</p>
            <Button asChild className="mt-6">
              <Link to="/poetry">Browse poetry</Link>
            </Button>
          </div>
        ) : (
          <div className="space-y-10">
            {verses.length ? (
              <section>
                <h2 className="font-display text-2xl">Verses</h2>
                <ul className="mt-3 space-y-2">
                  {verses.map((v) =>
                    v ? (
                      <li key={v.id}>
                        <Link to="/poetry/$id" params={{ id: v.id }} className="text-fg hover:underline">
                          {v.title}
                          <span className="text-muted"> — {getPoet(v.poetSlug)?.name}</span>
                        </Link>
                      </li>
                    ) : null,
                  )}
                </ul>
              </section>
            ) : null}
            {quotes.length ? (
              <section>
                <h2 className="font-display text-2xl">Quotes</h2>
                <ul className="mt-3 space-y-2">
                  {quotes.map((q) =>
                    q ? (
                      <li key={q.id}>
                        <Link to="/quotes" className="text-fg hover:underline">
                          {q.english}
                        </Link>
                      </li>
                    ) : null,
                  )}
                </ul>
              </section>
            ) : null}
            {stories.length ? (
              <section>
                <h2 className="font-display text-2xl">Stories</h2>
                <ul className="mt-3 space-y-2">
                  {stories.map((s) =>
                    s ? (
                      <li key={s.slug}>
                        <Link to="/stories/$slug" params={{ slug: s.slug }} className="hover:underline">
                          {s.title}
                        </Link>
                      </li>
                    ) : null,
                  )}
                </ul>
              </section>
            ) : null}
            {terms.length ? (
              <section>
                <h2 className="font-display text-2xl">Terms</h2>
                <ul className="mt-3 space-y-2">
                  {terms.map((t) =>
                    t ? (
                      <li key={t.slug}>
                        <Link to="/terms/$slug" params={{ slug: t.slug }} className="hover:underline">
                          {t.term}
                        </Link>
                      </li>
                    ) : null,
                  )}
                </ul>
              </section>
            ) : null}
            {qawwalis.length ? (
              <section>
                <h2 className="font-display text-2xl">Qawwali</h2>
                <ul className="mt-3 space-y-2">
                  {qawwalis.map((q) =>
                    q ? (
                      <li key={q.id}>
                        <Link to="/qawwali/$id" params={{ id: q.id }} className="hover:underline">
                          {q.title}
                        </Link>
                      </li>
                    ) : null,
                  )}
                </ul>
              </section>
            ) : null}
            {books.length ? (
              <section>
                <h2 className="font-display text-2xl">Books</h2>
                <ul className="mt-3 space-y-2">
                  {books.map((b) =>
                    b ? (
                      <li key={b.slug}>
                        <Link to="/ebooks/$slug" params={{ slug: b.slug }} className="hover:underline">
                          {b.title}
                        </Link>
                      </li>
                    ) : null,
                  )}
                </ul>
              </section>
            ) : null}
          </div>
        )}
      </div>
    </main>
  );
}
