import { createFileRoute } from "@tanstack/react-router";
import { PoetCard } from "@/components/poet-card";
import { PageHead } from "@/components/site-shell";
import { poets } from "@/lib/catalog";

export const Route = createFileRoute("/poets/")({ component: PoetsIndex });

function PoetsIndex() {
  return (
    <main>
      <PageHead
        kicker="The company"
        title="Poets"
        dek="Sixteen voices of the path — from Basra and Konya to Kashi, Kasur, and Bhit Shah."
      />
      <div className="mx-auto grid max-w-6xl gap-4 px-4 pb-16 sm:grid-cols-2 lg:grid-cols-3 md:px-6">
        {poets.map((p) => (
          <PoetCard key={p.slug} poet={p} />
        ))}
      </div>
    </main>
  );
}
