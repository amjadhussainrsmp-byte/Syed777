import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowLeft } from "lucide-react";
import { PoetMark } from "@/components/poet-card";
import { ScriptToggle } from "@/components/script-toggle";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { VerseBlock } from "@/components/verse-block";
import { getPoet, versesByPoet } from "@/lib/catalog";

export const Route = createFileRoute("/poets/$slug")({ component: PoetPage });

function PoetPage() {
  const { slug } = Route.useParams();
  const poet = getPoet(slug);
  const list = versesByPoet(slug);

  if (!poet) {
    return (
      <main className="mx-auto max-w-2xl px-4 py-24 text-center">
        <h1 className="font-display text-3xl">This poet is not on the shelf</h1>
        <Button asChild variant="outline" className="mt-6">
          <Link to="/poets">All poets</Link>
        </Button>
      </main>
    );
  }

  return (
    <main>
      <div className="relative isolate overflow-hidden">
        <img
          src="/images/jali.jpg"
          alt=""
          className="h-56 w-full object-cover md:h-72"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-bg via-bg/40 to-fg/20" />
      </div>
      <div className="mx-auto -mt-14 max-w-3xl px-4 pb-16 md:px-6">
        <Link to="/poets" className="mb-6 inline-flex h-11 items-center gap-2 text-sm text-muted hover:text-fg">
          <ArrowLeft className="size-4" /> All poets
        </Link>
        <div className="flex items-start gap-4 rounded-xl bg-surface p-6 shadow-[var(--shadow-border)]">
          <PoetMark poet={poet} className="size-20" />
          <div>
            <h1 className="font-display text-3xl md:text-4xl">{poet.name}</h1>
            <p className="mt-1 font-nastaliq text-xl text-muted" dir="rtl">
              {poet.nameOriginal}
            </p>
            <p className="mt-3 text-sm text-muted">
              {poet.years} · {poet.place}
            </p>
            <div className="mt-3 flex flex-wrap gap-2">
              <Badge variant="soft">{poet.tradition}</Badge>
              {poet.languages.map((l) => (
                <Badge key={l}>{l}</Badge>
              ))}
            </div>
          </div>
        </div>
        <p className="mt-8 text-lg leading-relaxed text-ink-soft">{poet.bio}</p>
        <div className="mt-12 flex items-center justify-between gap-4">
          <h2 className="font-display text-2xl">Verses</h2>
          <ScriptToggle />
        </div>
        <div className="mt-6 flex flex-col gap-4">
          {list.length === 0 ? (
            <p className="text-muted">No verses on the shelf yet.</p>
          ) : (
            list.map((v) => (
              <Link
                key={v.id}
                to="/poetry/$id"
                params={{ id: v.id }}
                className="rounded-xl bg-surface p-6 shadow-[var(--shadow-border)] transition-shadow duration-fast hover:shadow-[var(--shadow-border-hover)]"
              >
                <p className="mb-4 text-sm text-subtle">{v.title}</p>
                <VerseBlock verse={v} size="md" />
              </Link>
            ))
          )}
        </div>
      </div>
    </main>
  );
}
