import { poets, getPoet } from "./poets";
import { verses, getVerse, versesByPoet, versesByCollection } from "./verses";
import {
  articles,
  ebooks,
  getArticle,
  getEbook,
  getPlace,
  getQawwali,
  getQuote,
  getStory,
  getTerm,
  places,
  qawwalis,
  quotes,
  stories,
  terms,
  todaysQuote,
  todaysVerseIndex,
} from "./content";
import type { SearchHit } from "./types";

export * from "./types";
export {
  poets,
  getPoet,
  verses,
  getVerse,
  versesByPoet,
  versesByCollection,
  quotes,
  stories,
  terms,
  qawwalis,
  places,
  articles,
  ebooks,
  getQuote,
  getStory,
  getTerm,
  getQawwali,
  getPlace,
  getArticle,
  getEbook,
  todaysQuote,
};

export function featuredPoets() {
  return poets.filter((p) =>
    ["rumi", "hafiz", "khusrau", "kabir", "bulleh-shah", "rabia"].includes(p.slug),
  );
}

export function todaysVerse() {
  const v = verses[todaysVerseIndex() % verses.length];
  return v ?? verses[0]!;
}

export function searchAll(raw: string): SearchHit[] {
  const q = raw.trim().toLowerCase();
  if (q.length < 1) return [];
  const hits: SearchHit[] = [];

  const match = (...fields: Array<string | undefined>) =>
    fields.some((f) => f && f.toLowerCase().includes(q));

  for (const p of poets) {
    if (match(p.name, p.nameHindi, p.nameOriginal, p.place, p.tradition, p.bio)) {
      hits.push({
        href: `/poets/${p.slug}`,
        kind: "Poet",
        title: p.name,
        subtitle: `${p.years} · ${p.place}`,
      });
    }
  }
  for (const v of verses) {
    const poet = getPoet(v.poetSlug);
    if (match(v.title, v.original, v.hindi, v.roman, v.english, v.form, poet?.name)) {
      hits.push({
        href: `/poetry/${v.id}`,
        kind: v.form,
        title: v.title,
        subtitle: poet?.name ?? "",
      });
    }
  }
  for (const quote of quotes) {
    const poet = getPoet(quote.poetSlug);
    if (match(quote.english, quote.original, quote.roman, poet?.name)) {
      hits.push({
        href: `/quotes#${quote.id}`,
        kind: "Quote",
        title: quote.english.slice(0, 88),
        subtitle: poet?.name ?? "",
      });
    }
  }
  for (const s of stories) {
    if (match(s.title, s.dek, s.source, ...s.body)) {
      hits.push({ href: `/stories/${s.slug}`, kind: "Story", title: s.title, subtitle: s.source });
    }
  }
  for (const t of terms) {
    if (match(t.term, t.urdu, t.hindi, t.roman, t.meaning, t.longer)) {
      hits.push({ href: `/terms/${t.slug}`, kind: "Term", title: t.term, subtitle: t.meaning });
    }
  }
  for (const qw of qawwalis) {
    if (match(qw.title, qw.original, qw.hindi, qw.roman, qw.english, qw.language)) {
      hits.push({ href: `/qawwali/${qw.id}`, kind: "Qawwali", title: qw.title, subtitle: qw.language });
    }
  }
  for (const p of places) {
    if (match(p.name, p.city, p.saint, p.summary, ...p.body)) {
      hits.push({ href: `/places/${p.slug}`, kind: "Place", title: p.name, subtitle: p.city });
    }
  }
  for (const a of articles) {
    if (match(a.title, a.dek, ...a.body)) {
      hits.push({ href: `/articles/${a.slug}`, kind: "Article", title: a.title, subtitle: a.dek });
    }
  }
  for (const e of ebooks) {
    if (match(e.title, e.author, e.summary, ...e.excerpt)) {
      hits.push({ href: `/ebooks/${e.slug}`, kind: "Book", title: e.title, subtitle: e.author });
    }
  }
  return hits.slice(0, 40);
}

export const counts = {
  poets: poets.length,
  verses: verses.length,
  quotes: quotes.length,
  stories: stories.length,
  terms: terms.length,
  qawwalis: qawwalis.length,
  places: places.length,
  articles: articles.length,
  ebooks: ebooks.length,
};
