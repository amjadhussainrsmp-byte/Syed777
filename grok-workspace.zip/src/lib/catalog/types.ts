export type ScriptKind = "urdu" | "persian" | "hindi" | "punjabi" | "sindhi" | "arabic" | "turkish";

export type VerseForm =
  | "ghazal"
  | "doha"
  | "kafi"
  | "rubai"
  | "qawwali"
  | "shabad"
  | "masnavi"
  | "bait"
  | "bhajan"
  | "nazm";

export type CollectionId = "sufi-kalam" | "sant-vani";

export type Poet = {
  slug: string;
  name: string;
  nameOriginal: string;
  nameHindi: string;
  years: string;
  place: string;
  tradition: string;
  languages: string[];
  bio: string;
  hue: string;
};

export type Verse = {
  id: string;
  poetSlug: string;
  title: string;
  form: VerseForm;
  collection: CollectionId;
  original: string;
  originalScript: ScriptKind;
  hindi?: string;
  roman: string;
  english: string;
  note?: string;
};

export type Quote = {
  id: string;
  poetSlug: string;
  original?: string;
  originalScript?: ScriptKind;
  roman?: string;
  english: string;
};

export type Story = {
  slug: string;
  title: string;
  source: string;
  dek: string;
  body: string[];
};

export type Term = {
  slug: string;
  term: string;
  urdu: string;
  hindi: string;
  roman: string;
  meaning: string;
  longer: string;
};

export type Qawwali = {
  id: string;
  title: string;
  poetSlug?: string;
  language: string;
  original: string;
  originalScript: ScriptKind;
  hindi?: string;
  roman: string;
  english: string;
  note: string;
};

export type Place = {
  slug: string;
  name: string;
  city: string;
  saint: string;
  urs: string;
  summary: string;
  body: string[];
};

export type Article = {
  slug: string;
  title: string;
  dek: string;
  minutes: number;
  body: string[];
};

export type Ebook = {
  slug: string;
  title: string;
  author: string;
  year: string;
  language: string;
  summary: string;
  excerpt: string[];
};

export type SearchHit = {
  href: string;
  kind: string;
  title: string;
  subtitle: string;
};
