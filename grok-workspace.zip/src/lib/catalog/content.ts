import type { Article, Ebook, Place, Qawwali, Quote, Story, Term } from "./types";

export const quotes: Quote[] = [
  {
    id: "q-rumi-seek",
    poetSlug: "rumi",
    english: "What you seek is seeking you.",
    roman: "Aanche mijooyi to ra mijooyad",
    original: "آنچه می‌جویی تو را می‌جوید",
    originalScript: "persian",
  },
  {
    id: "q-rumi-silence",
    poetSlug: "rumi",
    english: "Silence is the language of God; all else is poor translation.",
  },
  {
    id: "q-hafiz-drop",
    poetSlug: "hafiz",
    english: "I wish I could show you, when you are lonely or in darkness, the astonishing light of your own being.",
  },
  {
    id: "q-khusrau-color",
    poetSlug: "khusrau",
    english: "I have become you, and you me. I am the body, you the soul. So that none can say afterwards: I am another, you another.",
    original: "من تو شدم تو من شدی، من تن شدم تو جان شدی\nتا کس نگوید بعد از این من دیگری تو دیگری",
    originalScript: "persian",
    roman: "Man to shudam to man shudi, man tan shudam to jaan shudi\nTa kas nagoyad ba'd az in, man digari to digari",
  },
  {
    id: "q-kabir-well",
    poetSlug: "kabir",
    english: "The clay said to the potter: why do you press me so? One day I will press you.",
    original: "माटी कहे कुम्हार से, तू क्या रौंदे मोहे\nएक दिन ऐसा आएगा, मैं रौंदूंगी तोहे",
    originalScript: "hindi",
    roman: "Maati kahe kumhar se, tu kya raunde mohe\nEk din aisa aayega, main raundungi tohe",
  },
  {
    id: "q-rabia-two-loves",
    poetSlug: "rabia",
    english: "I have loved You with two loves: a love of passion, and a love because You are worthy of it.",
    originalScript: "arabic",
    original: "أحبّك حبّين: حبّ الهوى وحبّاً لأنك أهل لذاكا",
  },
  {
    id: "q-saadi-kind",
    poetSlug: "saadi",
    english: "Have kindness for the weak, if you would have the strong be kind to you.",
  },
  {
    id: "q-attar-valley",
    poetSlug: "attar",
    english: "The valley of the quest is long. Do not ask how long. Walk.",
  },
  {
    id: "q-bahu-book",
    poetSlug: "sultan-bahu",
    english: "Reading books, they became scholars — but they never read their own hearts.",
    roman: "Parh parh ilm te faazil hoya, kadi apne aap nu parheya nahi",
  },
  {
    id: "q-yunus-heart",
    poetSlug: "yunus-emre",
    english: "The heart is the seat of God. Do not break a heart.",
  },
  {
    id: "q-ibn-mirror",
    poetSlug: "ibn-arabi",
    english: "The world is a mirror in which the Real sees His own face.",
  },
  {
    id: "q-lalon-cage",
    poetSlug: "lalon",
    english: "A strange bird lives in this cage of bone. If it flies, no one can catch it.",
  },
  {
    id: "q-bulleh-learn",
    poetSlug: "bulleh-shah",
    english: "You have read ten thousand books. Have you ever read your own self?",
  },
  {
    id: "q-farid-sweet",
    poetSlug: "baba-farid",
    english: "Farid: make sweet the tongue, and the Lord will make sweet the heart.",
  },
  {
    id: "q-bhittai-walk",
    poetSlug: "bhittai",
    english: "Those who sit, remain sitting. Those who walk, arrive.",
  },
];

export const stories: Story[] = [
  {
    slug: "reed-and-the-fire",
    title: "The reed and the fire",
    source: "After Rumi",
    dek: "Why the flute sounds like a human throat.",
    body: [
      "They asked the reed why it cried. It said: I was green in a bed of my own kind. A knife came, and then a knife again, until I was hollow. Then a man put fire to one end of me and his mouth to the other.",
      "I do not cry for the knife, the reed said. I cry because the breath that moves through me is not my own, and because the bed I came from is still growing, out of sight, and I can hear it.",
      "The listeners thought this a sad story. The reed thought it was the only true autobiography anyone had ever told.",
    ],
  },
  {
    slug: "moth-and-the-flame",
    title: "The moth and the flame",
    source: "After Attar",
    dek: "News of the fire is not the fire.",
    body: [
      "Three moths held a council about a candle burning in a far room. The first flew near, felt the heat, and came back. There is a brightness, it said, and it hurts a little.",
      "The second flew closer, scorched a wing, and returned proud. I have seen the source, it said. I bring you news.",
      "The third did not return. In the morning there was a small dark mark on the wax, and a silence where a report should have been.",
      "The first two wrote books. The third became the only accurate footnote.",
    ],
  },
  {
    slug: "rabia-torch",
    title: "The torch and the jug",
    source: "After Rabia of Basra",
    dek: "A woman walks through Basra carrying two impossible tools.",
    body: [
      "They saw Rabia in the street with a torch in one hand and a jug of water in the other. They asked her where she was going.",
      "I am going to burn Paradise, she said, and drown Hell, so that no one will love God from hope of a garden or fear of a fire.",
      "Then they asked her what would be left. She said: whatever was there before the garden and the fire were invented as wages.",
    ],
  },
  {
    slug: "elephant-in-the-dark",
    title: "The elephant in the dark",
    source: "After Rumi",
    dek: "Each hand was sure, and each hand was wrong.",
    body: [
      "An elephant was brought at night into a dark hall. The people of the town were invited to know it by touch.",
      "The one who found the ear said: it is a fan. The one who found the leg said: it is a pillar. The one who found the trunk said: it is a water-pipe. They argued until morning, each with a true piece and a false whole.",
      "Rumi says: if they had each held a candle, the quarrel would have died of light. The path is not the collecting of parts. It is the coming of a seeing that makes parts unnecessary.",
    ],
  },
  {
    slug: "moses-and-the-shepherd",
    title: "Moses and the shepherd",
    source: "After Rumi",
    dek: "A rebuke that had to be taken back.",
    body: [
      "Moses overheard a shepherd talking to God as to a friend: I would wash Your clothes, pick the lice from Your hair, bring You milk, kiss Your little hands.",
      "Moses, trained in proper speech, rebuked him. God is not a body. Do not talk like a village uncle.",
      "The shepherd tore his cloak and walked into the desert. Then a revelation came to Moses: you have separated a servant from Me. I did not send you to make people polite. For him, that broken speech was a mihrab. For you, the same words would be a wall.",
      "Moses ran after the shepherd to ask forgiveness. The shepherd said: I have gone past the place where language can reach. Thank you for shoving me.",
    ],
  },
  {
    slug: "conference-of-birds",
    title: "The conference of the birds",
    source: "After Attar",
    dek: "Thirty birds, seven valleys, one face.",
    body: [
      "The hoopoe called the birds of the world to a quest for the Simurgh, the king they had never seen. Most made excuses: the nightingale was in love with a rose, the duck could not leave water, the hawk served a king already.",
      "A remnant set out. They crossed the valleys of quest, love, knowledge, detachment, unity, bewilderment, and poverty. Many fell away. Thirty arrived.",
      "On the far side of the last valley they saw a mirror. Si murgh: thirty birds. Simurgh: the name of the king. The face they had travelled toward was the face they had travelled with, seen together, at last.",
    ],
  },
  {
    slug: "lost-key",
    title: "The key under the lamp",
    source: "After a dervish tale",
    dek: "Why we search where the light is good.",
    body: [
      "A dervish was on his knees under a street-lamp. A neighbour asked what he had lost. A key, he said. They both searched the bright circle of the lamp.",
      "After a while the neighbour asked: are you sure you dropped it here? No, said the dervish. I dropped it in the house. Then why look here? Because here, said the dervish, there is light.",
      "The neighbour walked away muttering about fools. The dervish smiled, because the neighbour had understood the joke and missed the teaching. We look for the Friend in the places that are already lit — books, shrines, arguments — and the key is in the unlit room of the chest.",
    ],
  },
  {
    slug: "bayazid-door",
    title: "Bayazid at the door",
    source: "After the Tadhkirat al-Awliya",
    dek: "Who is knocking.",
    body: [
      "Bayazid came to a door in himself and knocked. Who is there? said a voice. It is I, said Bayazid. The door stayed shut.",
      "He went away for years — some say into the desert, some say into ordinary work. He came back and knocked. Who is there? It is You, said Bayazid.",
      "The door opened. There was no one in the house who was not already the one who had been knocking.",
    ],
  },
];

export const terms: Term[] = [
  {
    slug: "fana",
    term: "Fana",
    urdu: "فنا",
    hindi: "फ़ना",
    roman: "fanaa",
    meaning: "Annihilation of the self in the Real.",
    longer:
      "Fana is not suicide and not a mood. In the classical manuals it is the falling-away of the seeker's claim to be a separate actor, so that what acts is understood as the Real acting. The old teachers pair it with baqa: remaining, afterwards, in God, able to walk the market without the old self putting on a turban.",
  },
  {
    slug: "baqa",
    term: "Baqa",
    urdu: "بقا",
    hindi: "बक़ा",
    roman: "baqaa",
    meaning: "Subsistence in God after fana.",
    longer:
      "If fana is the uncooking of the self, baqa is the dish that can be served. The one who remains is not a ghost. He buys bread, greets neighbours, and no longer takes the 'I' as a private kingdom.",
  },
  {
    slug: "ishq",
    term: "Ishq",
    urdu: "عشق",
    hindi: "इश्क़",
    roman: "ishq",
    meaning: "Love that does not bargain.",
    longer:
      "Ishq is the word the poets prefer to hubb when they mean a love that burns the house. In Sufi speech it is both the path and the destination: the attraction that pulls the reed back toward the bed it was cut from. Human love is not a rival to it; it is often the school in which it is first tasted.",
  },
  {
    slug: "tawhid",
    term: "Tawhid",
    urdu: "توحید",
    hindi: "तौहीद",
    roman: "tawheed",
    meaning: "The declaration — and then the tasting — of oneness.",
    longer:
      "On the tongue, tawhid is the sentence there is no god but God. On the path it becomes a seeing: that multiplicity is real as appearance and not as a second rival to the Real. The poets of wahdat al-wujud pressed this until the sentence itself began to glow.",
  },
  {
    slug: "dhikr",
    term: "Dhikr",
    urdu: "ذکر",
    hindi: "ज़िक्र",
    roman: "zikr",
    meaning: "Remembrance of the Name.",
    longer:
      "Dhikr is the work of bringing the Name back to the tongue, the breath, and the heart until forgetfulness is the stranger. It may be silent or voiced, alone or in a circle. The qawwali gathering is a public, musical form of the same labour.",
  },
  {
    slug: "sama",
    term: "Sama",
    urdu: "سماع",
    hindi: "समा",
    roman: "samaa",
    meaning: "Audition: listening as a spiritual practice.",
    longer:
      "Sama is the gathering in which verse and music are used as a means of presence. The Chishtis of the subcontinent made it central; other orders fenced it with conditions, or forbade it. Qawwali as it is sung at dargahs is the living South Asian form of sama.",
  },
  {
    slug: "murshid",
    term: "Murshid / Murid",
    urdu: "مرشد / مرید",
    hindi: "मुर्शिद / मुरीद",
    roman: "murshid / mureed",
    meaning: "Guide and seeker.",
    longer:
      "The murid is the one who wants. The murshid is the one who has been wanted long enough to become a door. The relationship is not fandom and not a contract of flattery. In the old books it is a surgery performed with love, on the nafs, over years.",
  },
  {
    slug: "khanqah",
    term: "Khanqah",
    urdu: "خانقاہ",
    hindi: "ख़ानक़ाह",
    roman: "khanqaah",
    meaning: "A lodge of teaching and hospitality.",
    longer:
      "A khanqah is a house where the silsila lives: kitchen, cells, a hall for dhikr, a door that is supposed to open for the traveller. It is not a mosque (though it may contain one) and not a tomb. When the teacher is buried there, the khanqah often becomes a dargah.",
  },
  {
    slug: "dargah",
    term: "Dargah",
    urdu: "درگاہ",
    hindi: "दरगाह",
    roman: "dargaah",
    meaning: "The threshold of a saint — shrine and courtyard.",
    longer:
      "Dargah means a royal court, and then the threshold of a wali. In the subcontinent it is the tomb-complex: grave, mosque, langar, the trees where qawwals sit. People come with petitions, with thanks, and with no theology at all — only a need to sit where someone sat who did not turn the hungry away.",
  },
  {
    slug: "urs",
    term: "Urs",
    urdu: "عرس",
    hindi: "उर्स",
    roman: "urs",
    meaning: "The wedding: a saint's death-anniversary.",
    longer:
      "Urs in Arabic is a wedding. The death of a wali is kept as the day of union with the Beloved, not as a funeral. The annual urs at a dargah is a fair, a vigil, a feeding, and a concert. The metaphors of marriage in Sufi verse are not decoration; they are the calendar.",
  },
  {
    slug: "hama-ost",
    term: "Hama ost",
    urdu: "ہمہ اوست",
    hindi: "हमा ओस्त",
    roman: "hama-ost",
    meaning: "All is He.",
    longer:
      "A Persian sentence of wahdat al-wujud: everything you meet is a face of the One. It is not a claim that stones are God in a crude way. It is a claim that there is no second. The poets use it as a key; the theologians argue about the lock.",
  },
  {
    slug: "qalandar",
    term: "Qalandar",
    urdu: "قلندر",
    hindi: "क़लंदर",
    roman: "qalandar",
    meaning: "The unbound dervish.",
    longer:
      "The qalandar shaves the conventional signs of piety and walks a little outside the orderly khanqah. Lal Shahbaz of Sehwan is the great qalandar of the Indus. The cry dam-a-dam mast qalandar is both a name and a state: breath by breath, intoxicated, free.",
  },
];

export const qawwalis: Qawwali[] = [
  {
    id: "man-kunto",
    title: "Man kunto maula",
    poetSlug: "khusrau",
    language: "Arabic / Persian / Hindavi",
    originalScript: "persian",
    original: "من كنت مولاه فعلي مولاه\nیار در من آمد و من از خود برفتم",
    hindi: "मन कुन्तो मौला फ़ हाज़ा अली-उन मौला",
    roman: "Man kunto maula fa hadha Ali-un maula",
    english:
      "Whoever takes me as a friend, Ali is their friend. Khusrau's setting of the Prophet's word at Ghadir Khumm became a cornerstone of Chishti qawwali.",
    note: "Traditionally attributed in its musical form to Amir Khusrau, sung at the start of a Mehfil-e-Sama.",
  },
  {
    id: "chhap-tilak",
    title: "Chhap tilak sab cheeni",
    poetSlug: "khusrau",
    language: "Hindavi",
    originalScript: "hindi",
    original: "छाप तिलक सब छीनी रे मोसे नैन मिलाइके\nप्रेम भटी का मदवा पिलाइके",
    hindi: "छाप तिलक सब छीनी रे मोसे नैन मिलाइके",
    roman: "Chhap tilak sab cheeni re mose nain milaaike",
    english: "You took my caste-marks and my tilak merely by meeting my eyes, and made me drink at the tavern of love.",
    note: "See the full verse on Khusrau's page. A standard of the Nizamuddin courtyard.",
  },
  {
    id: "dama-dam",
    title: "Dama dam mast qalandar",
    language: "Punjabi / Sindhi / Seraiki",
    originalScript: "punjabi",
    original: "او لال مری پٹ رکھیو بلا جھولے لالن\nسندھڑی دا، سیون دا، سخی شہباز قلندر\nدما دم مست قلندر، علی دم دم دے اندر",
    hindi: "ओ लाल मेरी पट रखियो बला झूले लालन\nसिन्धड़ी दा, सेहवन दा, सखी शाहबाज़ क़लंदर",
    roman: "O laal meri pat rakhio bala jhoole laalan\nSindhri da, Sehwan da, sakhi Shahbaz Qalandar\nDama dam mast qalandar, Ali dam dam de andar",
    english:
      "O red one, keep my honour, O swinging beloved. Of Sindh, of Sehwan, generous Shahbaz Qalandar. Breath by breath, the intoxicated qalandar — Ali in every breath.",
    note: "A processional kalam of Lal Shahbaz Qalandar, endlessly re-sung from Sehwan to the radio.",
  },
  {
    id: "aaj-rang",
    title: "Aaj rang hai",
    poetSlug: "khusrau",
    language: "Hindavi",
    originalScript: "hindi",
    original: "आज रंग है री माँ रंग है री\nमेरे महबूब के घर रंग है री",
    hindi: "आज रंग है री माँ रंग है री",
    roman: "Aaj rang hai ri maa rang hai ri, mere mahboob ke ghar rang hai ri",
    english: "Today there is colour, mother — colour in the house of my beloved.",
    note: "Sung as a cry of finding the murshid. The colour is the colour of the Chishti court.",
  },
  {
    id: "ali-maula",
    title: "Ali maula Ali maula",
    language: "Urdu / Persian",
    originalScript: "urdu",
    original: "علی مولا علی مولا علی مولا علی\nہائے نہ جانے کیسی مایا رچی",
    hindi: "अली मौला अली मौला अली मौला अली",
    roman: "Ali maula Ali maula Ali maula Ali",
    english: "Ali, the friend — Ali, the friend. A manqabat in praise of Ali ibn Abi Talib, sung until the hall becomes a single name.",
    note: "A manqabat rather than a narrative qawwali; the repetition is the point.",
  },
  {
    id: "tere-ishq",
    title: "Tere ishq nachaya",
    poetSlug: "bulleh-shah",
    language: "Punjabi",
    originalScript: "punjabi",
    original: "تیرے عشق نچایا کر تھیہ تھیہ",
    hindi: "तेरे इश्क़ नचाया कर थेया थेया",
    roman: "Tere ishq nachaya kar theya theya",
    english: "Your love made me dance. A kafi that becomes qawwali when the tabla takes the theya theya into the body.",
    note: "Bulleh Shah's kafi, danced as often as it is sung.",
  },
];

export const places: Place[] = [
  {
    slug: "ajmer",
    name: "Ajmer Sharif",
    city: "Ajmer, Rajasthan",
    saint: "Khwaja Moinuddin Chishti",
    urs: "Rajab (6th–7th, lunar)",
    summary: "The threshold of Gharib Nawaz, the helper of the poor, from which the Chishti silsila spread through the subcontinent.",
    body: [
      "Khwaja Moinuddin Chishti came to Ajmer at the turn of the thirteenth century and sat down among people the court did not count. The dargah that grew around his grave is still a kitchen as much as a tomb: the deghs in the courtyard feed whoever arrives.",
      "The urs in Rajab fills the lanes of Ajmer with qawwali, rose, and the unfashionable work of asking. Gharib Nawaz — patron of the poor — is a title the shrine has to keep earning, night after night, in the langar.",
    ],
  },
  {
    slug: "nizamuddin",
    name: "Hazrat Nizamuddin",
    city: "Delhi",
    saint: "Nizamuddin Auliya",
    urs: "Rabi' al-thani (lunar)",
    summary: "A courtyard in the middle of Delhi where Khusrau still sings to his pir.",
    body: [
      "Nizamuddin Auliya taught a politics of the kitchen: that a saint's worth is measured in who is fed. His disciple Amir Khusrau is buried a few steps away. The evening qawwali here is not a concert so much as a conversation that has not ended since 1325.",
      "The baoli, the mosque, the graves of later Chishtis, and the crush of the bazaar make a single sentence: the path was never only in the desert. It was also in a city that would not stay still.",
    ],
  },
  {
    slug: "pakpattan",
    name: "Baba Farid's shrine",
    city: "Pakpattan",
    saint: "Fariduddin Ganj-e-Shakar",
    urs: "Muharram (5th, lunar)",
    summary: "The house of the first great Punjabi poet of the path, where a door is still crawled through as a prayer.",
    body: [
      "Ajodhan became Pakpattan — the holy ferry — because Farid sat here. The Bihishti Darwaza is opened in the urs and pilgrims pass through it as through a sentence they cannot yet read.",
      "His Punjabi shlokas in the Guru Granth Sahib mean that Sikhs, Muslims, and the unlabelled poor have been reading the same dry, glittering humility for centuries.",
    ],
  },
  {
    slug: "sehwan",
    name: "Sehwan Sharif",
    city: "Sehwan, Sindh",
    saint: "Lal Shahbaz Qalandar",
    urs: "18–19 Sha'ban (lunar)",
    summary: "The red saint of the Indus, and a dhamal that does not ask your papers.",
    body: [
      "Lal Shahbaz Qalandar, the red falcon, is buried at Sehwan in a shrine that sounds like a heart. The dhamal — a drum-led turning — is the house practice. Dam-a-dam mast qalandar is not a song you listen to here. It is a weather.",
      "The urs draws fakirs, families, and people who would not be welcome in neater holy places. That is the qalandar's old job.",
    ],
  },
  {
    slug: "konya",
    name: "Rumi's shrine",
    city: "Konya",
    saint: "Jalaluddin Rumi",
    urs: "17 December (Sheb-i Arus)",
    summary: "The wedding night of Mawlana, kept each year as a turning toward the Friend.",
    body: [
      "The green dome in Konya holds Rumi, and near him Shams is remembered. The Mevlevi sama — the slow turning with one palm up and one down — is a reading of the Masnavi with the body.",
      "Sheb-i Arus, the wedding night, marks the day of his death as a marriage. Visitors who have never read a line of Persian still know to be quiet when the reed begins.",
    ],
  },
  {
    slug: "bhit-shah",
    name: "Bhit Shah",
    city: "Bhit Shah, Sindh",
    saint: "Shah Abdul Latif Bhittai",
    urs: "14–16 Safar (lunar)",
    summary: "A mound of sand, a tambura, and the heroines of Sindh walking all night.",
    body: [
      "Shah Latif sat on a bhit, a dune, and the town grew around the sitting. At the urs the Shah Jo Risalo is sung for three nights. Sassui still walks the stones. Marui still refuses the palace.",
      "The shrine is a reminder that a vernacular — Sindhi, in this case — can carry as much of the path as the old imperial tongues.",
    ],
  },
];

export const articles: Article[] = [
  {
    slug: "what-is-sama",
    title: "What is sama",
    dek: "Listening as a door, not as entertainment.",
    minutes: 6,
    body: [
      "Sama means audition. In the manuals it is a contested mercy: some orders built their house on it, some fenced it, some forbade it for the unripe. The argument was never really about music. It was about whether the heart may be moved by a created beauty toward an uncreated one, or whether it will stop at the singer.",
      "In the Chishti courtyards of the subcontinent the argument was settled in practice. Qawwali — a Persian word for the one who says — became a liturgy of repetition. A line is thrown, caught, turned, and thrown again until it is no longer information. It is weather in the chest.",
      "The adab of a mehfil is strict in its way. One does not clap as at a concert. One does not treat the saint as a celebrity and the qawwal as a cover band. The music is a means. When it works, the means becomes transparent. When it fails, it is still, at worst, beautiful — which is why the cautious teachers worried.",
      "To sit in sama is to agree, for an hour, that listening might be a deed. Noornama cannot play you the drum. It can put the words in your hand so that when you do hear them, you are not a tourist to your own language.",
    ],
  },
  {
    slug: "how-to-read-a-ghazal",
    title: "How to read a ghazal",
    dek: "Each couplet is a room. The poem is a street.",
    minutes: 5,
    body: [
      "A ghazal is a set of couplets that share a metre, a rhyme, and a refrain, and do not owe one another a plot. You can lift a sher out and it should still stand. This offends readers trained on narrative. It is a gift to readers trained on prayer.",
      "The last couplet often contains the poet's takhallus — the pen-name — as if the writer had walked into their own room. Hafiz talks to Hafiz. Ghalib complains about Ghalib. The self is a character, not a throne.",
      "Wine, the cupbearer, the mosque, the tavern, the mole, the breeze of dawn: these are a kit. Sometimes they mean what they say. Sometimes they mean the Real. A good reading keeps both possibilities in the mouth and does not swallow too fast.",
      "On this site a verse is offered in several scripts because a ghazal is a sound as much as a meaning. If you can, read the original aloud even when you cannot yet parse it. The mouth learns before the dictionary does.",
    ],
  },
  {
    slug: "chishti-path",
    title: "The Chishti path in the subcontinent",
    dek: "A silsila that chose the kitchen.",
    minutes: 7,
    body: [
      "The Chishti order came into India with Khwaja Moinuddin and took a decision that still shapes the courtyards: to live among the poor, to keep a langar, to use the local tongue, and to allow sama. Nizamuddin Auliya in Delhi made the decision famous. Baba Farid made it Punjabi. Khusrau made it sing.",
      "Other paths emphasised law, or isolation, or a more cautious ear. The Chishtis gambled on hospitality. The gamble's monument is the dargah: not a fortress of the saved, but a threshold. Anyone may come. Not everyone will stay. The door does not inspect papers.",
      "To read Chishti kalam is to hear a theology of the guest. The Friend is the guest. The poor are the guest. You are, on a good day, the door.",
    ],
  },
  {
    slug: "why-the-poets-remain",
    title: "Why these poets remain",
    dek: "Not as heritage. As a still-working tool.",
    minutes: 5,
    body: [
      "Sufi verse survives the way a well survives: because people are still thirsty, not because a ministry declared it heritage. A doha of Kabir can still puncture a procession. A kafi of Bulleh Shah can still make a scholar feel overdressed. A line of Hafiz can still be drawn like a card when a life stalls.",
      "The academy will always want to sort them: syncretic, subaltern, Indo-Persian, proto-secular. Sorting is a legitimate labour. It is not the same labour as reading with the chest.",
      "Noornama is a reading-room. It does not replace a murshid, a mehfil, or a library. It is a lamp on a table, and a few open books, and a chair. If you leave with one line stuck to you, the table has done its work.",
    ],
  },
];

export const ebooks: Ebook[] = [
  {
    slug: "masnavi",
    title: "Masnavi-ye Ma'navi",
    author: "Jalaluddin Rumi",
    year: "c. 1258–1273",
    language: "Persian",
    summary: "The great teaching poem: stories within stories, jokes, rebukes, and the reed's complaint.",
    excerpt: [
      "Listen to the reed-flute, how it tells a tale, complaining of separations. Ever since I was cut from the reed-bed, my lament has made men and women moan.",
      "I want a breast torn by parting, that I may unfold the pain of the ache of love. Whoever is left far from his source wishes back the time when he was one with it.",
    ],
  },
  {
    slug: "divan-hafiz",
    title: "Divan-e-Hafiz",
    author: "Hafiz Shirazi",
    year: "14th century",
    language: "Persian",
    summary: "Ghazals of wine, the Beloved, and the unmasking of the professional pietist.",
    excerpt: [
      "If that Shirazi Turk would take my heart in hand, I would give Samarkand and Bukhara for his Hindu mole.",
      "The one whose heart has been made living by love never dies. Our permanence is written on the ledger of the world.",
    ],
  },
  {
    slug: "mantiq-al-tayr",
    title: "The Conference of the Birds",
    author: "Fariduddin Attar",
    year: "c. 1177",
    language: "Persian",
    summary: "A flock, seven valleys, and a name that was thirty birds all along.",
    excerpt: [
      "The hoopoe said: I am the messenger of the unseen, and I know the way to the Simurgh. Whoever has the courage, come.",
      "When the thirty arrived they saw a mirror. They had been looking for a king. They found a seeing.",
    ],
  },
  {
    slug: "gulistan",
    title: "Gulistan",
    author: "Saadi Shirazi",
    year: "1258",
    language: "Persian",
    summary: "The Rose Garden: short tales, sharp morals, and a prose that walks.",
    excerpt: [
      "The children of Adam are limbs of one body, created of one essence. When fortune inflicts pain on one limb, the others cannot remain at rest.",
      "Saadi wrote this in a book meant to be carried, not enshrined. Read a page. Put it down. Live a little. Come back.",
    ],
  },
  {
    slug: "shah-jo-risalo",
    title: "Shah Jo Risalo",
    author: "Shah Abdul Latif Bhittai",
    year: "18th century",
    language: "Sindhi",
    summary: "Surs of the desert heroines, sung through the night at Bhit Shah.",
    excerpt: [
      "Sassui walks the stones because Punhun has gone. The walking is the prayer. Arrival, if it comes, is not a station on the map.",
      "Marui in the palace still smells the smoke of her village. Comfort is the test she was not willing to pass.",
    ],
  },
  {
    slug: "kabir-bijak",
    title: "Bijak of Kabir",
    author: "Kabir",
    year: "15th century",
    language: "Hindi",
    summary: "The weaver's book: dohas and ramainis that refuse both temple and mosque as final addresses.",
    excerpt: [
      "Where do you search for me, friend? I am here, beside you. Not in pilgrimage, not in an idol, not in Kaaba or Kailash.",
      "Musk lives in the deer's own navel, and the deer hunts it through the forest.",
    ],
  },
];

export function getQuote(id: string) {
  return quotes.find((q) => q.id === id);
}
export function getStory(slug: string) {
  return stories.find((s) => s.slug === slug);
}
export function getTerm(slug: string) {
  return terms.find((t) => t.slug === slug);
}
export function getQawwali(id: string) {
  return qawwalis.find((q) => q.id === id);
}
export function getPlace(slug: string) {
  return places.find((p) => p.slug === slug);
}
export function getArticle(slug: string) {
  return articles.find((a) => a.slug === slug);
}
export function getEbook(slug: string) {
  return ebooks.find((e) => e.slug === slug);
}

export function todaysQuote(): Quote {
  const day = Math.floor(Date.now() / 86400000);
  return quotes[day % quotes.length] ?? quotes[0]!;
}

export function todaysVerseIndex() {
  return Math.floor(Date.now() / 86400000);
}
