import * as React from "react";
import { cn } from "@/lib/utils";

const Input = React.forwardRef<HTMLInputElement, React.ComponentProps<"input">>(
  ({ className, type, ...props }, ref) => {
    return (
      <input
        type={type}
        className={cn(
          "flex h-11 w-full rounded-md border border-border bg-surface px-4 text-base text-fg shadow-[var(--shadow-border)] transition-[box-shadow,border-color] duration-quick ease-smooth placeholder:text-subtle focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring md:text-sm",
          className,
        )}
        ref={ref}
        {...props}
      />
    );
  },
);
Input.displayName = "Input";

export { Input };
